import json
import logging
import threading
import time
import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable
import requests

import i18n

from config_manager import get_session_data
from payments.billing_country_service import BillingCountryService
from payments.pricing_service import get_pricing_service, PricingPlan

_ = i18n._
logger = logging.getLogger("plan_selector")

DEFAULT_CURRENCY = "USD"


def _is_brazil(locale_str: str) -> bool:
    """Verifica se uma string de locale/country indica Brasil.
    
    Aceita: 'BR', 'br', 'pt_BR', 'pt-BR', 'pt_BR.UTF-8', etc.
    """
    if not locale_str or not isinstance(locale_str, str):
        return False
    loc = locale_str.lower().strip()
    # Check for BR country code or Portuguese-Brazil locale
    return (
        loc == "br" or
        loc.startswith("pt_br") or
        loc.startswith("pt-br") or
        loc == "pt_br" or
        loc == "pt-br"
    )


def _detect_country_from_ip() -> Optional[str]:
    """
    Detecta país baseado no IP público do usuário (para guest users).
    
    Usa múltiplos serviços de geolocalização como fallback:
    1. ipapi.co (gratuito, primário)
    2. ip-api.com (gratuito, backup)
    
    Returns:
        Código ISO do país (ex: 'BR', 'US') ou None se falhar
    """
    import hashlib
    import json
    import time
    import requests
    from pathlib import Path
    
    logger = logging.getLogger("plan_selector")
    
    # Cache local baseado no IP (válido por 24h)
    cache_dir = Path.home() / ".voxfluens" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / "ip_country_cache.json"
    
    # Tentar obter IP público primeiro
    logger.info("🌍 Getting public IP...")
    public_ip = _get_public_ip()
    if not public_ip:
        logger.warning("🌍 Could not determine public IP")
        return None
        
    logger.info("🌍 Public IP: %s", public_ip)
        
    # Verificar cache
    cache_key = hashlib.md5(public_ip.encode()).hexdigest()
    now = time.time()
    
    try:
        if cache_file.exists():
            with open(cache_file, 'r') as f:
                cache = json.load(f)
                
            if cache_key in cache:
                cached_data = cache[cache_key]
                if now - cached_data['timestamp'] < 86400:  # 24h
                    logger.info(f"🌍 Using cached country: {cached_data['country']}")
                    return cached_data['country']
    except Exception as e:
        logger.debug(f"🌍 Cache read error: {e}")
    
    # Tentar serviços de geolocalização com circuit breaker
    services = [
        ("ipapi.co", lambda ip: f"https://ipapi.co/{ip}/json/", 3),  # timeout 3s
        ("ip-api.com", lambda ip: f"http://ip-api.com/json/{ip}", 2),  # timeout 2s
        ("ipapi.co (backup)", lambda ip: f"https://ipapi.co/{ip}/country/", 2),  # endpoint mais simples
    ]

    failed_services = 0
    max_failures = 2  # Parar após 2 falhas consecutivas

    for service_name, url_func, timeout in services:
        if failed_services >= max_failures:
            logger.warning(f"🌍 Stopping after {max_failures} consecutive failures")
            break

        try:
            url = url_func(public_ip)
            logger.debug(f"🌍 Trying {service_name}: {url} (timeout: {timeout}s)")

            start_time = time.time()
            response = requests.get(url, timeout=timeout)
            response_time = time.time() - start_time

            response.raise_for_status()

            data = response.json()
            country = _extract_country_from_geo_data(data, service_name)

            if country:
                logger.info(f"🌍 Detected country via {service_name}: {country} ({response_time:.2f}s)")
                # Salvar no cache
                try:
                    cache = {}
                    if cache_file.exists():
                        with open(cache_file, 'r') as f:
                            cache = json.load(f)

                    cache[cache_key] = {
                        'country': country,
                        'timestamp': now,
                        'service': service_name,
                        'response_time': response_time
                    }

                    with open(cache_file, 'w') as f:
                        json.dump(cache, f)

                except Exception as e:
                    logger.debug(f"🌍 Cache write error: {e}")

                return country
            else:
                logger.warning(f"🌍 {service_name} returned no country data")
                failed_services += 1

        except requests.exceptions.Timeout:
            logger.warning(f"🌍 {service_name} timeout after {timeout}s")
            failed_services += 1
        except requests.exceptions.RequestException as e:
            logger.warning(f"🌍 {service_name} failed: {e}")
            failed_services += 1
        except Exception as e:
            logger.warning(f"🌍 {service_name} error: {e}")
            failed_services += 1
    
    logger.warning("🌍 All geolocation services failed")
    return None


def _get_public_ip() -> Optional[str]:
    """Obtém IP público usando múltiplos serviços com circuit breaker."""
    services = [
        ("ipify", "https://api.ipify.org?format=json", 2),
        ("ipapi.co", "https://ipapi.co/json/", 2),
        ("ip-api.com", "http://ip-api.com/json/", 3),
        ("icanhazip", "http://icanhazip.com/", 2),  # fallback simples
    ]

    failed_services = 0
    max_failures = 2

    for service_name, url, timeout in services:
        if failed_services >= max_failures:
            logger.warning(f"🌍 Stopping IP detection after {max_failures} consecutive failures")
            break

        try:
            logger.debug(f"🌍 Trying {service_name} for IP detection")
            response = requests.get(url, timeout=timeout)
            response.raise_for_status()
            data = response.json()

            if 'ip' in data:
                ip = data['ip']
                logger.info(f"🌍 Public IP detected via {service_name}: {ip}")
                return ip
            elif service_name == "icanhazip":
                # icanhazip retorna apenas o IP como texto
                ip = data.strip() if isinstance(data, str) else str(data).strip()
                if ip:
                    logger.info(f"🌍 Public IP detected via {service_name}: {ip}")
                    return ip

        except requests.exceptions.Timeout:
            logger.warning(f"🌍 {service_name} IP detection timeout")
            failed_services += 1
        except Exception as e:
            logger.debug(f"🌍 {service_name} IP detection error: {e}")
            failed_services += 1

    logger.warning("🌍 Could not determine public IP from any service")
    return None
    
    return None


def _extract_country_from_geo_data(data: dict, service_name: str) -> Optional[str]:
    """Extrai código do país dos dados de geolocalização."""
    try:
        if service_name == "ipapi.co":
            return data.get('country_code')
        elif service_name == "ip-api.com":
            return data.get('countryCode')
    except Exception:
        pass
    return None


def detect_currency(billing_service: Optional[BillingCountryService] = None) -> str:
    """Detecta moeda do usuário com segurança máxima contra fraude.

    ⚠️ CRÍTICO PARA SEGURANÇA: Preços em BRL são mais baratos - não permitir
    que usuários de fora do Brasil acessem checkout em BRL.

    Estratégia (em ordem de prioridade - BACKEND ONLY):
    1) COUNTRY OVERRIDE (experimental - para testes de pagamento em diferentes moedas)
    2) BillingCountryService (dashboard billing_country - mais seguro)
    3) Fallback para session data (backend billing_country)
    4) Fallback para geolocalização por IP (guest users)
    5) Fallback conservador: USD (nunca adivinhar)

    ❌ NUNCA usar language/locale para pricing (evita fraude via mudança de idioma)

    GARANTIA DE SEGURANÇA:
    - Frontend usa APENAS backend billing_country
    - Backend valida billing_country no checkout
    """
    logger.info("💰 Starting currency detection...")
    try:
        # 0️⃣ SIMULAÇÃO: Verificar country override para testes (deve vir primeiro!)
        from config_manager import get_country_override
        country_override = get_country_override()
        if country_override:
            if _is_brazil(country_override):
                logger.info("✅ Currency detection: BRL via COUNTRY OVERRIDE (simulation mode) country='%s'", country_override)
                return "BRL"
            else:
                logger.info("✅ Currency detection: USD via COUNTRY OVERRIDE (simulation mode) country='%s'", country_override)
                return "USD"
        
        # 1️⃣ PREFERÊNCIA: Usar BillingCountryService (dashboard billing_country - mais seguro)
        # 1️⃣ PREFERÊNCIA: Usar BillingCountryService (dashboard billing_country - mais seguro)
        if billing_service:
            try:
                # Verificar se billing_country já está carregado
                if hasattr(billing_service, 'billing_country') and billing_service.billing_country:
                    country = billing_service.billing_country
                else:
                    # Tentar carregar se não estiver
                    try:
                        billing_service.load_dashboard()
                        country = billing_service.billing_country
                    except Exception:
                        country = None
                
                if country:
                    if _is_brazil(country):
                        logger.info("✅ Currency detection: BRL via BillingCountryService billing_country='%s'", country)
                        return "BRL"
                    else:
                        logger.info("✅ Currency detection: USD via BillingCountryService billing_country='%s' (not BR)", country)
                        return "USD"
                else:
                    logger.warning("⚠️ BillingCountryService has no billing_country, falling back to session data")
            except Exception as e:
                logger.warning("⚠️ BillingCountryService failed: %s, falling back to session data", str(e))
        
        # 2️⃣ FALLBACK: Usar session data do backend (billing_country)
        session = get_session_data()
        country = session.get("user_data", {}).get("billing_country") or session.get("billing", {}).get("country")
        
        # Para guest users, usar geolocalização por IP (fonte da verdade)
        is_guest = session.get("is_guest", False) or not session.get("access_token")
        if is_guest:
            logger.info("🌍 Guest user detected, using IP geolocation for currency detection")
            geo_country = _detect_country_from_ip()
            if geo_country:
                if _is_brazil(geo_country):
                    logger.info("✅ Currency detection: BRL via IP geolocation country='%s'", geo_country)
                    return "BRL"
                else:
                    logger.info("✅ Currency detection: USD via IP geolocation country='%s' (not BR)", geo_country)
                    return "USD"
            else:
                logger.warning("⚠️ IP geolocation failed for guest user, using USD fallback")
                return "USD"
        
        if country:
            if _is_brazil(country):
                logger.info("✅ Currency detection: BRL via backend billing_country='%s'", country)
                return "BRL"
            else:
                logger.info("✅ Currency detection: USD via backend billing_country='%s' (not BR)", country)
                return "USD"

        # If we're a logged-in user without a backend billing_country, try IP geolocation as a secondary
        # fallback for display purposes only (backend must still validate on checkout).
        if not is_guest:
            logger.info("🔎 No billing_country set for logged-in user; attempting IP geolocation as secondary fallback")
            try:
                geo_country = _detect_country_from_ip()
                if geo_country:
                    if _is_brazil(geo_country):
                        logger.info("✅ Currency detection: BRL via IP geolocation fallback for logged-in user country='%s'", geo_country)
                        return "BRL"
                    else:
                        logger.info("✅ Currency detection: USD via IP geolocation fallback for logged-in user country='%s' (not BR)", geo_country)
                        return "USD"
                else:
                    logger.warning("⚠️ IP geolocation failed for logged-in user, using USD fallback")
            except Exception as e:
                logger.warning("⚠️ IP geolocation attempt for logged-in user failed: %s", str(e))

        # 3️⃣ FALLBACK: Para usuários sem billing_country estabelecida, usar USD por segurança
        logger.info("✅ Currency detection: USD (fallback - no billing_country available)")
        return "USD"
        
    except Exception as e:
        # Em caso de erro, sempre retorna USD (seguro)
        logger.error("❌ Currency detection error: %s, using safe default USD", str(e))
        return "USD"


def detect_currency_async(callback: Callable[[str], None], billing_service: Optional[BillingCountryService] = None, root_widget=None) -> None:
    """Detecta moeda do usuário de forma assíncrona para não bloquear a UI.

    Args:
        callback: Função a ser chamada com o resultado (currency: str)
        billing_service: Serviço de billing opcional
        root_widget: Widget tkinter para agendar callback na thread principal
    """
    def _detect_async():
        logger.info("🔄 Starting async currency detection in background thread")
        try:
            currency = detect_currency(billing_service)
            logger.info("✅ Currency detected in background: %s", currency)
            # Chamar callback na thread principal
            if callback:
                def _call_callback():
                    try:
                        logger.info("📞 Calling callback with currency: %s", currency)
                        callback(currency)
                    except Exception as e:
                        logger.error("❌ Error in currency detection callback: %s", str(e))

                # Usar after() do widget root para garantir execução na thread principal
                if root_widget:
                    try:
                        logger.info("📅 Scheduling callback with root_widget.after(0)")
                        root_widget.after(0, _call_callback)
                    except Exception as e:
                        logger.warning("❌ Could not schedule callback with root_widget: %s", str(e))
                        # Fallback: tentar usar _default_root ou chamar diretamente
                        try:
                            import tkinter
                            if tkinter._default_root and tkinter._default_root != root_widget:
                                logger.info("📅 Fallback: Scheduling callback with tkinter._default_root.after(0)")
                                tkinter._default_root.after(0, _call_callback)
                            else:
                                logger.warning("⚠️ No valid root for after(), calling callback directly")
                                _call_callback()
                        except Exception as fallback_e:
                            logger.warning("⚠️ Fallback also failed (%s), calling callback directly", str(fallback_e))
                            _call_callback()
                else:
                    # Fallback: tentar usar _default_root
                    try:
                        import tkinter
                        if tkinter._default_root:
                            logger.info("📅 Scheduling callback with tkinter._default_root.after(0)")
                            tkinter._default_root.after(0, _call_callback)
                        else:
                            logger.warning("⚠️ No _default_root, calling callback directly")
                            _call_callback()
                    except Exception as e:
                        logger.warning("⚠️ Exception with _default_root (%s), calling callback directly", str(e))
                        _call_callback()
        except Exception as e:
            logger.error("❌ Async currency detection failed: %s", str(e))
            try:
                if root_widget:
                    root_widget.after(0, lambda: callback("USD"))
                else:
                    callback("USD")  # Fallback seguro
            except Exception as callback_error:
                logger.error("❌ Callback error in async detection: %s", str(callback_error))

    # Executar detecção em thread separada
    logger.info("🧵 Starting background thread for currency detection")
    thread = threading.Thread(target=_detect_async, daemon=True)
    thread.start()


class PlanSelectorFrame(ttk.Frame):
    """
    Frame para seleção de planos PRO com suporte a multi-moeda.
    
    Características:
    - ✅ Detecção automática de moeda (BRL/USD)
    - ✅ Segurança contra fraude de preços
    - ✅ Suporte a BillingCountryService para integração com backend
    - ✅ Fallback conservador para USD
    
    Uso:
        frame = PlanSelectorFrame(parent, on_upgrade=callback)
        # ou com serviço:
        service = BillingCountryService(api_url, token)
        frame = PlanSelectorFrame(parent, on_upgrade=callback, billing_service=service)
    """
    
    def __init__(
        self,
        parent,
        on_upgrade=None,
        currency=None,
        billing_service: Optional[BillingCountryService] = None,
        is_checkout_active: bool = False,  # New: track checkout state
        on_checkout_state_change=None,  # Callback for parent to sync state
        is_guest_mode: bool = False,
        **kwargs
    ):
        super().__init__(parent, **kwargs)

        # Track instances on the parent for duplicate detection (no debug logs)
        try:
            instances = getattr(parent, '_plan_selector_instances', [])
            instances.append(self)
            setattr(parent, '_plan_selector_instances', instances)
        except Exception:
            pass

        # Ensure we remove reference from parent on destroy to avoid stale tracking
        try:
            def _on_destroy(event=None, parent=parent, selfref=self):
                try:
                    instances = getattr(parent, '_plan_selector_instances', [])
                    if selfref in instances:
                        instances.remove(selfref)
                        setattr(parent, '_plan_selector_instances', instances)
                except Exception:
                    pass
            self.bind('<Destroy>', _on_destroy)
        except Exception:
            pass
        self.is_guest_mode = is_guest_mode
        self.on_upgrade = on_upgrade
        self.billing_service = billing_service
        self.is_checkout_active = is_checkout_active
        self.on_checkout_state_change = on_checkout_state_change

        # Initialize pricing service
        self.pricing_service = get_pricing_service()

        session = get_session_data()
        # Use session's is_guest as source of truth if parameter not explicitly passed
        if not is_guest_mode and session.get('is_guest', False):
            self.is_guest_mode = True

        # Tkinter variable for plan selection (lazy initialization)
        self._plan_var = None

        # Loading and error states
        self._loading = False
        self._error_message = None
        self._pricing_plans = []
        self.prices_are_dynamic = False

        # Determinar moeda
        if currency and currency in ['BRL', 'USD']:
            self.currency = currency
            self._currency_explicit = True
            logger.info("Currency set explicitly: %s", self.currency)
        else:
            # Detectar moeda automaticamente (synchronous initial guess)
            self._currency_explicit = False
            self.currency = detect_currency(billing_service)
            logger.info("Currency detected (initial): %s", self.currency)

            # Kick off asynchronous re-check to improve detection (e.g., geolocation for logged-in users)
            def _currency_callback(new_currency):
                try:
                    if not self._currency_explicit and new_currency and new_currency != self.currency:
                        logger.info("Currency re-detected asynchronously: %s -> %s, updating UI", self.currency, new_currency)
                        self.currency = new_currency
                        # Load fallback plans for the new currency and rebuild UI on main thread
                        try:
                            self._pricing_plans = self.pricing_service.get_pricing_plans(self.currency)
                        except Exception:
                            self._pricing_plans = self.pricing_service._get_fallback_plans(self.currency)
                        self.after(0, lambda: self._build_ui())
                except Exception as e:
                    logger.debug("Currency async callback error: %s", e)

            try:
                # Use billing_service when available for more accurate detection
                detect_currency_async(_currency_callback, billing_service=billing_service, root_widget=self)
            except Exception as e:
                logger.debug("Could not schedule async currency detection: %s", e)

        # Load fallback plans immediately for instant UI
        self._pricing_plans = self.pricing_service.get_pricing_plans(self.currency)
        self._loading = False
        self._error_message = None

        # Async refresh in background
        self._fetch_pricing_data_async_only()

        # Build UI
        self._build_ui()

    def _fetch_pricing_data_async_only(self):
        """Async refresh without blocking initial UI."""
        # Reset dynamic indicator before async fetch (do not rebuild here to avoid duplicate creations)
        self.prices_are_dynamic = False

        def on_pricing_loaded(plans):
            if plans and len(plans) > 0:  # Only set dynamic if we got actual plans from API
                self.prices_are_dynamic = True
                self._pricing_plans = plans
                # Schedule UI update on main thread
                self.after(0, lambda: self._build_ui())

        self.pricing_service.fetch_pricing_plans_async(self.currency, on_pricing_loaded)

    def _fetch_pricing_data(self):
        """Legacy method - now just calls async refresh."""
        self._fetch_pricing_data_async_only()

    def _build_ui(self):
        """Rebuild the UI with current pricing data."""
        # Clear existing widgets
        for widget in list(self.winfo_children()):
            try:
                widget.destroy()
            except Exception:
                pass

        # Ensure _pricing_plans is a list
        if not hasattr(self, '_pricing_plans') or not isinstance(self._pricing_plans, list):
            self._pricing_plans = []

    @property
    def plan_var(self):
        """Lazy initialization of plan_var to avoid Tkinter root window issues."""
        if self._plan_var is None:
            try:
                # Prefer creating a Tk StringVar bound to this widget
                self._plan_var = tk.StringVar(master=self)
            except Exception:
                # Fall back to a tiny in-memory stand-in for tests that mock tkinter
                class _DummyVar:
                    def __init__(self):
                        self._v = ""
                    def set(self, v):
                        self._v = v
                    def get(self):
                        return self._v
                self._plan_var = _DummyVar()
        return self._plan_var

    def _build_ui(self):
        # Ensure _pricing_plans is a list
        if not hasattr(self, '_pricing_plans') or not isinstance(self._pricing_plans, list):
            self._pricing_plans = []

        # Configure frame background to match UI standards
        style = ttk.Style()
        style.configure("PlanSelector.TFrame", background="#F8FAFC")
        style.configure("PlanSelector.TLabel", background="#F8FAFC")
        style.configure("PlanSelector.TRadiobutton", background="#F8FAFC")
        self.configure(style="PlanSelector.TFrame")
        
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        title = ttk.Label(
            self,
            text=_("Escolha seu plano PRO"),
            font=("Segoe UI", 14, "bold"),
            foreground="#2563EB",
            style="PlanSelector.TLabel",
        )
        title.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 10))

        # Show pricing source indicator
        if self.prices_are_dynamic:
            status_text = _("Preços atualizados do servidor")
            status_color = "#059669"  # Green
        else:
            status_text = _("Preços padrão (servidor indisponível)")
            status_color = "#6B7280"  # Gray

        # Remove any pre-existing status-like labels to avoid overlap
        try:
            for w in list(self.winfo_children()):
                try:
                    if isinstance(w, ttk.Label) and ("Preços" in (w.cget('text') or "")):
                        w.destroy()
                except Exception:
                    continue
        except Exception:
            pass

        status_label = ttk.Label(
            self,
            text=status_text,
            font=("Segoe UI", 9),
            foreground=status_color,
            style="PlanSelector.TLabel",
            anchor="w",
            justify="left",
        )
        status_label.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(4, 12))

        # End of status label handling

        # Handle loading state
        if self._loading:
            loading_label = ttk.Label(
                self,
                text=_("Carregando preços..."),
                font=("Segoe UI", 10),
                foreground="#64748B",
                style="PlanSelector.TLabel",
            )
            loading_label.grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 10))
            return

        # Handle error state
        if self._error_message:
            error_label = ttk.Label(
                self,
                text=self._error_message,
                font=("Segoe UI", 10),
                foreground="#DC2626",
                wraplength=320,
                style="PlanSelector.TLabel",
            )
            error_label.grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 10))
            # Still show plans if available (fallback)
            if not self._pricing_plans:
                return

        # Build plan selection UI (descrição em linha separada)
        row_cursor = 3 if self._error_message else 2
        if self._pricing_plans:
            for plan in self._pricing_plans:
                key = f"{self.currency.lower()}_{plan.interval}"
                radio = ttk.Radiobutton(
                    self,
                    text=f"{plan.name} · {plan.display_price}",
                    variable=self.plan_var,
                    value=key,
                    style="PlanSelector.TRadiobutton",
                )
                radio.grid(row=row_cursor, column=0, columnspan=2, sticky="ew", pady=(0, 2))
                desc = ttk.Label(
                    self,
                    text="; ".join(plan.features[:2]) if plan.features else "Plano PRO completo",
                    font=("Segoe UI", 9),
                    foreground="#1E293B",
                    style="PlanSelector.TLabel",
                    justify="left",
                )
                desc.grid(row=row_cursor + 1, column=0, columnspan=2, sticky="ew", padx=(20, 0), pady=(0, 5))
                row_cursor += 2

            # Set default to yearly plan if available
            yearly_plans = [p for p in self._pricing_plans if p.interval == "yearly"]
            if yearly_plans:
                yearly_key = f"{self.currency.lower()}_yearly"
                self.plan_var.set(yearly_key)
        else:
            # Fallback to hardcoded config if no dynamic plans
            fallback_config = {
                "BRL": {
                    "monthly": {
                        "label": "PRO Mensal",
                        "price": "R$ 29,00",
                        "desc": "Transcrições ilimitadas e suporte prioritário.",
                    },
                    "yearly": {
                        "label": "PRO Anual",
                        "price": "R$ 299,00",
                        "desc": "Economize 16,7% em comparação ao plano mensal.",
                    },
                },
                "USD": {
                    "monthly": {
                        "label": "PRO Monthly",
                        "price": "$9.99",
                        "desc": "Unlimited transcriptions and priority support.",
                    },
                    "yearly": {
                        "label": "PRO Yearly",
                        "price": "$99.99",
                        "desc": "Save 16.6% compared to the monthly plan.",
                    },
                },
            }
            config = fallback_config.get(self.currency, fallback_config[DEFAULT_CURRENCY])
            for interval, tier in config.items():
                key = f"{self.currency.lower()}_{interval}"
                radio = ttk.Radiobutton(
                    self,
                    text=f"{tier['label']} · {tier['price']}",
                    variable=self.plan_var,
                    value=key,
                    style="PlanSelector.TRadiobutton",
                )
                radio.grid(row=row_cursor, column=0, columnspan=2, sticky="ew", pady=(0, 2))
                desc = ttk.Label(
                    self,
                    text=tier["desc"],
                    font=("Segoe UI", 9),
                    foreground="#1E293B",
                    style="PlanSelector.TLabel",
                    justify="left",
                )
                desc.grid(row=row_cursor + 1, column=0, columnspan=2, sticky="ew", padx=(20, 0), pady=(0, 5))
                row_cursor += 2

            # Definir plano anual como padrão
            yearly_key = f"{self.currency.lower()}_yearly"
            if yearly_key in [f"{self.currency.lower()}_{interval}" for interval in config.keys()]:
                self.plan_var.set(yearly_key)

        # Calculate row offset for button placement
        button_row = row_cursor

        btn_disabled = self.is_guest_mode
        self.btn_upgrade = tk.Button(
            self,
            text=self._get_button_text(),
            command=self._on_upgrade_clicked if not btn_disabled else None,
            state="disabled" if btn_disabled else "normal",
            bg="#9CA3AF" if btn_disabled else "#2563EB",
            cursor="arrow" if btn_disabled else "hand2",
            fg="#FFFFFF",
            font=("Segoe UI", 10, "bold"),
            bd=0,
            height=1,  # 32px approx with pady
            padx=20,
            pady=8,  # Reduced for 32px height
        )
        self.btn_upgrade.grid(row=button_row, column=0, columnspan=2, pady=(15, 5), sticky="ew")
        self.btn_upgrade.bind("<Enter>", self._on_button_hover)
        self.btn_upgrade.bind("<Leave>", self._on_button_leave)

        # Spinner label (hidden initially)
        self.spinner_label = ttk.Label(self, text="⏳ Aguardando confirmação...", font=("Segoe UI", 10), style="PlanSelector.TLabel")
        self.spinner_label.grid(row=button_row + 1, column=0, columnspan=2, pady=(0, 5), sticky="ew")
        self.spinner_label.grid_remove()  # Hide initially

        self.hint = ttk.Label(
            self,
            text=_("Tudo incluso: suporte prioritário, limites maiores e segurança Stripe."),
            font=("Segoe UI", 9),
            foreground="#64748B",
            style="PlanSelector.TLabel",
        )
        self.hint.grid(row=button_row + 1, column=0, columnspan=2, sticky="ew")

    def _get_button_text(self):
        if self.is_checkout_active:
            return _("⏳ Checkout em andamento...")
        base = _("Upgrade para PRO")
        if self.is_guest_mode:
            base += " (necessário criar conta)"
        return base

    def set_checkout_active(self, active: bool):
        """Called by parent during polling."""
        self.is_checkout_active = active
        is_disabled = active or self.is_guest_mode
        self.btn_upgrade.configure(
            text=self._get_button_text(),
            command=self._on_upgrade_clicked if not is_disabled else None,
            state="disabled" if is_disabled else "normal",
            bg="#2563EB" if not is_disabled else "#9CA3AF",
            cursor="hand2" if not is_disabled else "arrow",
        )
        if active:
            self.spinner_label.grid()
        else:
            self.spinner_label.grid_remove()
        if self.on_checkout_state_change:
            self.on_checkout_state_change(active)

    def _on_button_hover(self, event):
        # Only hover if not guest and not checkout active
        if not self.is_guest_mode and not self.is_checkout_active and self.btn_upgrade["state"] == "normal":
            self.btn_upgrade.config(bg="#1D4ED8")  # Hover

    def _on_button_leave(self, event):
        # Only change color back if not guest and not checkout active
        if not self.is_guest_mode and not self.is_checkout_active:
            self.btn_upgrade.config(bg="#2563EB")

    def _on_upgrade_clicked(self):
        """Handle upgrade button click com suporte a checkout Stripe."""
        selected = self.plan_var.get()
        
        # Log da seleção
        logger.info("User selected plan: %s", selected)
        
        if self.on_upgrade:
            self.on_upgrade(selected, billing_service=self.billing_service)
            self.set_checkout_active(True) # Self-disable immediately
    
    def get_currency(self) -> str:
        """Retorna moeda detectada para este frame."""
        return self.currency
    
    def get_billing_country(self) -> Optional[str]:
        """Retorna país de cobrança se disponível via BillingCountryService."""
        if self.billing_service:
            try:
                return self.billing_service.billing_country
            except Exception:
                return None
        return None

    def _on_detection_timeout(self):
        """Callback chamado se a detecção demorar muito (fallback)."""
        if self.detection_completed:
            logger.debug("Detection already completed, ignoring timeout")
            return
            
        logger.warning("⏱️ Currency detection timed out, using fallback USD")
        self._on_currency_detected("USD")

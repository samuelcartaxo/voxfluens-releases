import json
import logging
import threading
import time
import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable
import requests

import i18n

from config_manager import get_session_data
from payments.billing_country_service import BillingCountryService

_ = i18n._
logger = logging.getLogger("plan_selector")

PRICE_CONFIG = {
    "BRL": {
        "monthly": {
            "label": _("PRO Mensal"),
            "price": "R$ 29,00",
            "desc": _("Transcrições ilimitadas e suporte prioritário."),
        },
        "yearly": {
            "label": _("PRO Anual"),
            "price": "R$ 299,00",
            "desc": _("Economize 16,7% em comparação ao plano mensal."),
        },
    },
    "USD": {
        "monthly": {
            "label": _("PRO Monthly"),
            "price": "$9.99",
            "desc": _("Unlimited transcriptions and priority support."),
        },
        "yearly": {
            "label": _("PRO Yearly"),
            "price": "$99.99",
            "desc": _("Save 16.6% compared to the monthly plan."),
        },
    },
}

DEFAULT_CURRENCY = "USD"


def _is_brazil(locale_str: str) -> bool:
    """Verifica se uma string de locale/country indica Brasil.
    
    Aceita: 'BR', 'br', 'pt_BR', 'pt-BR', 'pt_BR.UTF-8', etc.
    """
    if not locale_str or not isinstance(locale_str, str):
        return False
    loc = locale_str.lower().strip()
    # Check for BR country code or Portuguese-Brazil locale
    return (
        loc == "br" or
        loc.startswith("pt_br") or
        loc.startswith("pt-br") or
        loc == "pt_br" or
        loc == "pt-br"
    )


def _detect_country_from_ip() -> Optional[str]:
    """
    Detecta país baseado no IP público do usuário (para guest users).
    
    Usa múltiplos serviços de geolocalização como fallback:
    1. ipapi.co (gratuito, primário)
    2. ip-api.com (gratuito, backup)
    
    Returns:
        Código ISO do país (ex: 'BR', 'US') ou None se falhar
    """
    import hashlib
    import json
    import time
    import requests
    from pathlib import Path
    
    logger = logging.getLogger("plan_selector")
    
    # Cache local baseado no IP (válido por 24h)
    cache_dir = Path.home() / ".voxfluens_cache"
    cache_dir.mkdir(exist_ok=True)
    cache_file = cache_dir / "ip_country_cache.json"
    
    # Tentar obter IP público primeiro
    logger.info("🌍 Getting public IP...")
    public_ip = _get_public_ip()
    if not public_ip:
        logger.warning("🌍 Could not determine public IP")
        return None
        
    logger.info("🌍 Public IP: %s", public_ip)
        
    # Verificar cache
    cache_key = hashlib.md5(public_ip.encode()).hexdigest()
    now = time.time()
    
    try:
        if cache_file.exists():
            with open(cache_file, 'r') as f:
                cache = json.load(f)
                
            if cache_key in cache:
                cached_data = cache[cache_key]
                if now - cached_data['timestamp'] < 86400:  # 24h
                    logger.info(f"🌍 Using cached country: {cached_data['country']}")
                    return cached_data['country']
    except Exception as e:
        logger.debug(f"🌍 Cache read error: {e}")
    
    # Tentar serviços de geolocalização com circuit breaker
    services = [
        ("ipapi.co", lambda ip: f"https://ipapi.co/{ip}/json/", 3),  # timeout 3s
        ("ip-api.com", lambda ip: f"http://ip-api.com/json/{ip}", 2),  # timeout 2s
        ("ipapi.co (backup)", lambda ip: f"https://ipapi.co/{ip}/country/", 2),  # endpoint mais simples
    ]

    failed_services = 0
    max_failures = 2  # Parar após 2 falhas consecutivas

    for service_name, url_func, timeout in services:
        if failed_services >= max_failures:
            logger.warning(f"🌍 Stopping after {max_failures} consecutive failures")
            break

        try:
            url = url_func(public_ip)
            logger.debug(f"🌍 Trying {service_name}: {url} (timeout: {timeout}s)")

            start_time = time.time()
            response = requests.get(url, timeout=timeout)
            response_time = time.time() - start_time

            response.raise_for_status()

            data = response.json()
            country = _extract_country_from_geo_data(data, service_name)

            if country:
                logger.info(f"🌍 Detected country via {service_name}: {country} ({response_time:.2f}s)")
                # Salvar no cache
                try:
                    cache = {}
                    if cache_file.exists():
                        with open(cache_file, 'r') as f:
                            cache = json.load(f)

                    cache[cache_key] = {
                        'country': country,
                        'timestamp': now,
                        'service': service_name,
                        'response_time': response_time
                    }

                    with open(cache_file, 'w') as f:
                        json.dump(cache, f)

                except Exception as e:
                    logger.debug(f"🌍 Cache write error: {e}")

                return country
            else:
                logger.warning(f"🌍 {service_name} returned no country data")
                failed_services += 1

        except requests.exceptions.Timeout:
            logger.warning(f"🌍 {service_name} timeout after {timeout}s")
            failed_services += 1
        except requests.exceptions.RequestException as e:
            logger.warning(f"🌍 {service_name} failed: {e}")
            failed_services += 1
        except Exception as e:
            logger.warning(f"🌍 {service_name} error: {e}")
            failed_services += 1
    
    logger.warning("🌍 All geolocation services failed")
    return None


def _get_public_ip() -> Optional[str]:
    """Obtém IP público usando múltiplos serviços com circuit breaker."""
    services = [
        ("ipify", "https://api.ipify.org?format=json", 2),
        ("ipapi.co", "https://ipapi.co/json/", 2),
        ("ip-api.com", "http://ip-api.com/json/", 3),
        ("icanhazip", "http://icanhazip.com/", 2),  # fallback simples
    ]

    failed_services = 0
    max_failures = 2

    for service_name, url, timeout in services:
        if failed_services >= max_failures:
            logger.warning(f"🌍 Stopping IP detection after {max_failures} consecutive failures")
            break

        try:
            logger.debug(f"🌍 Trying {service_name} for IP detection")
            response = requests.get(url, timeout=timeout)
            response.raise_for_status()
            data = response.json()

            if 'ip' in data:
                ip = data['ip']
                logger.info(f"🌍 Public IP detected via {service_name}: {ip}")
                return ip
            elif service_name == "icanhazip":
                # icanhazip retorna apenas o IP como texto
                ip = data.strip() if isinstance(data, str) else str(data).strip()
                if ip:
                    logger.info(f"🌍 Public IP detected via {service_name}: {ip}")
                    return ip

        except requests.exceptions.Timeout:
            logger.warning(f"🌍 {service_name} IP detection timeout")
            failed_services += 1
        except Exception as e:
            logger.debug(f"🌍 {service_name} IP detection error: {e}")
            failed_services += 1

    logger.warning("🌍 Could not determine public IP from any service")
    return None
    
    return None


def _extract_country_from_geo_data(data: dict, service_name: str) -> Optional[str]:
    """Extrai código do país dos dados de geolocalização."""
    try:
        if service_name == "ipapi.co":
            return data.get('country_code')
        elif service_name == "ip-api.com":
            return data.get('countryCode')
    except Exception:
        pass
    return None


def detect_currency(billing_service: Optional[BillingCountryService] = None) -> str:
    """Detecta moeda do usuário com segurança máxima contra fraude.

    ⚠️ CRÍTICO PARA SEGURANÇA: Preços em BRL são mais baratos - não permitir
    que usuários de fora do Brasil acessem checkout em BRL.

    Estratégia (em ordem de prioridade - BACKEND ONLY):
    1) BillingCountryService (dashboard billing_country - mais seguro)
    2) Fallback para session data (backend billing_country)
    3) Fallback para geolocalização por IP (guest users)
    4) Fallback conservador: USD (nunca adivinhar)

    ❌ NUNCA usar language/locale para pricing (evita fraude via mudança de idioma)

    GARANTIA DE SEGURANÇA:
    - Frontend usa APENAS backend billing_country
    - Backend valida billing_country no checkout
    """
    logger.info("💰 Starting currency detection...")
    try:
        # 1️⃣ PREFERÊNCIA: Usar BillingCountryService (dashboard billing_country - mais seguro)
        if billing_service:
            try:
                # Verificar se billing_country já está carregado
                if hasattr(billing_service, 'billing_country') and billing_service.billing_country:
                    country = billing_service.billing_country
                else:
                    # Tentar carregar se não estiver
                    try:
                        billing_service.load_dashboard()
                        country = billing_service.billing_country
                    except Exception:
                        country = None
                
                if country:
                    if _is_brazil(country):
                        logger.info("✅ Currency detection: BRL via BillingCountryService billing_country='%s'", country)
                        return "BRL"
                    else:
                        logger.info("✅ Currency detection: USD via BillingCountryService billing_country='%s' (not BR)", country)
                        return "USD"
                else:
                    logger.warning("⚠️ BillingCountryService has no billing_country, falling back to session data")
            except Exception as e:
                logger.warning("⚠️ BillingCountryService failed: %s, falling back to session data", str(e))
        
        # 2️⃣ FALLBACK: Usar session data do backend (billing_country)
        session = get_session_data()
        country = session.get("user_data", {}).get("billing_country") or session.get("billing", {}).get("country")
        
        # Para guest users, usar geolocalização por IP (fonte da verdade)
        is_guest = session.get("is_guest", False) or not session.get("access_token")
        if is_guest:
            logger.info("🌍 Guest user detected, using IP geolocation for currency detection")
            geo_country = _detect_country_from_ip()
            if geo_country:
                if _is_brazil(geo_country):
                    logger.info("✅ Currency detection: BRL via IP geolocation country='%s'", geo_country)
                    return "BRL"
                else:
                    logger.info("✅ Currency detection: USD via IP geolocation country='%s' (not BR)", geo_country)
                    return "USD"
            else:
                logger.warning("⚠️ IP geolocation failed for guest user, using USD fallback")
                return "USD"
        
        if country:
            if _is_brazil(country):
                logger.info("✅ Currency detection: BRL via backend billing_country='%s'", country)
                return "BRL"
            else:
                logger.info("✅ Currency detection: USD via backend billing_country='%s' (not BR)", country)
                return "USD"
        
        # 3️⃣ FALLBACK: Para usuários sem billing_country estabelecida, usar USD por segurança
        logger.info("✅ Currency detection: USD (fallback - no billing_country available)")
        return "USD"
        
    except Exception as e:
        # Em caso de erro, sempre retorna USD (seguro)
        logger.error("❌ Currency detection error: %s, using safe default USD", str(e))
        return "USD"


def detect_currency_async(callback: Callable[[str], None], billing_service: Optional[BillingCountryService] = None, root_widget=None) -> None:
    """Detecta moeda do usuário de forma assíncrona para não bloquear a UI.

    Args:
        callback: Função a ser chamada com o resultado (currency: str)
        billing_service: Serviço de billing opcional
        root_widget: Widget tkinter para agendar callback na thread principal
    """
    def _detect_async():
        logger.info("🔄 Starting async currency detection in background thread")
        try:
            currency = detect_currency(billing_service)
            logger.info("✅ Currency detected in background: %s", currency)
            # Chamar callback na thread principal
            if callback:
                def _call_callback():
                    try:
                        logger.info("📞 Calling callback with currency: %s", currency)
                        callback(currency)
                    except Exception as e:
                        logger.error("❌ Error in currency detection callback: %s", str(e))

                # Usar after() do widget root para garantir execução na thread principal
                if root_widget:
                    try:
                        logger.info("📅 Scheduling callback with root_widget.after(0)")
                        root_widget.after(0, _call_callback)
                    except Exception as e:
                        logger.warning("❌ Could not schedule callback with root_widget: %s", str(e))
                        # Fallback: tentar usar _default_root ou chamar diretamente
                        try:
                            import tkinter
                            if tkinter._default_root and tkinter._default_root != root_widget:
                                logger.info("📅 Fallback: Scheduling callback with tkinter._default_root.after(0)")
                                tkinter._default_root.after(0, _call_callback)
                            else:
                                logger.warning("⚠️ No valid root for after(), calling callback directly")
                                _call_callback()
                        except Exception as fallback_e:
                            logger.warning("⚠️ Fallback also failed (%s), calling callback directly", str(fallback_e))
                            _call_callback()
                else:
                    # Fallback: tentar usar _default_root
                    try:
                        import tkinter
                        if tkinter._default_root:
                            logger.info("📅 Scheduling callback with tkinter._default_root.after(0)")
                            tkinter._default_root.after(0, _call_callback)
                        else:
                            logger.warning("⚠️ No _default_root, calling callback directly")
                            _call_callback()
                    except Exception as e:
                        logger.warning("⚠️ Exception with _default_root (%s), calling callback directly", str(e))
                        _call_callback()
        except Exception as e:
            logger.error("❌ Async currency detection failed: %s", str(e))
            try:
                if root_widget:
                    root_widget.after(0, lambda: callback("USD"))
                else:
                    callback("USD")  # Fallback seguro
            except Exception as callback_error:
                logger.error("❌ Callback error in async detection: %s", str(callback_error))

    # Executar detecção em thread separada
    logger.info("🧵 Starting background thread for currency detection")
    thread = threading.Thread(target=_detect_async, daemon=True)
    thread.start()


class PlanSelectorFrame(ttk.Frame):
    """
    Frame para seleção de planos PRO com suporte a multi-moeda.
    
    Características:
    - ✅ Detecção automática de moeda (BRL/USD)
    - ✅ Segurança contra fraude de preços
    - ✅ Suporte a BillingCountryService para integração com backend
    - ✅ Fallback conservador para USD
    
    Uso:
        frame = PlanSelectorFrame(parent, on_upgrade=callback)
        # ou com serviço:
        service = BillingCountryService(api_url, token)
        frame = PlanSelectorFrame(parent, on_upgrade=callback, billing_service=service)
    """
    
    def __init__(
        self,
        parent,
        on_upgrade=None,
        currency=None,
        billing_service: Optional[BillingCountryService] = None,
        is_checkout_active: bool = False,  # New: track checkout state
        on_checkout_state_change=None,  # Callback for parent to sync state
        is_guest_mode: bool = False,
        **kwargs
    ):
        super().__init__(parent, **kwargs)
        self.is_guest_mode = is_guest_mode
        self.on_upgrade = on_upgrade
        self.billing_service = billing_service
        self.is_checkout_active = is_checkout_active
        self.on_checkout_state_change = on_checkout_state_change

        session = get_session_data()
        # Use session's is_guest as source of truth if parameter not explicitly passed
        if not is_guest_mode and session.get('is_guest', False):
            self.is_guest_mode = True

        # Tkinter variable for plan selection (lazy initialization)
        self._plan_var = None

        # Determinar moeda
        if currency and currency in PRICE_CONFIG:
            self.currency = currency
            logger.info("Currency set explicitly: %s", self.currency)
        else:
            # Detectar moeda automaticamente
            self.currency = detect_currency(billing_service)
            logger.info("Currency detected: %s", self.currency)

        self._build_ui()

    @property
    def plan_var(self):
        """Lazy initialization of plan_var to avoid Tkinter root window issues."""
        if self._plan_var is None:
            self._plan_var = tk.StringVar()
        return self._plan_var

    def _build_ui(self):
        # Configure frame background to match UI standards
        style = ttk.Style()
        style.configure("PlanSelector.TFrame", background="#F8FAFC")
        style.configure("PlanSelector.TLabel", background="#F8FAFC")
        style.configure("PlanSelector.TRadiobutton", background="#F8FAFC")
        self.configure(style="PlanSelector.TFrame")
        
        self.columnconfigure(0, weight=1)
        title = ttk.Label(
            self,
            text=_("Escolha seu plano PRO"),
            font=("Segoe UI", 14, "bold"),
            foreground="#2563EB",
            style="PlanSelector.TLabel",
        )
        title.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))

        config = PRICE_CONFIG.get(self.currency, PRICE_CONFIG[DEFAULT_CURRENCY])
        for idx, (interval, tier) in enumerate(config.items(), start=1):
            key = f"{self.currency.lower()}_{interval}"
            radio = ttk.Radiobutton(
                self,
                text=f"{tier['label']} · {tier['price']}",
                variable=self.plan_var,
                value=key,
                style="PlanSelector.TRadiobutton",
            )
            radio.grid(row=idx, column=0, sticky="w", pady=(0, 5))
            desc = ttk.Label(
                self,
                text=tier["desc"],
                font=("Segoe UI", 9),
                foreground="#1E293B",
                style="PlanSelector.TLabel",
            )
            desc.grid(row=idx, column=1, sticky="w", padx=(10, 0))

        # Definir plano anual como padrão
        yearly_key = f"{self.currency.lower()}_yearly"
        if yearly_key in [f"{self.currency.lower()}_{interval}" for interval in config.keys()]:
            self.plan_var.set(yearly_key)

        btn_disabled = self.is_guest_mode
        self.btn_upgrade = tk.Button(
            self,
            text=self._get_button_text(),
            command=self._on_upgrade_clicked if not btn_disabled else None,
            state="disabled" if btn_disabled else "normal",
            bg="#9CA3AF" if btn_disabled else "#2563EB",
            cursor="arrow" if btn_disabled else "hand2",
            fg="#FFFFFF",
            font=("Segoe UI", 10, "bold"),
            bd=0,
            height=1,  # 32px approx with pady
            padx=20,
            pady=8,  # Reduced for 32px height
        )
        self.btn_upgrade.grid(row=len(config) + 1, column=0, columnspan=2, pady=(15, 5), sticky="ew")
        self.btn_upgrade.bind("<Enter>", self._on_button_hover)
        self.btn_upgrade.bind("<Leave>", self._on_button_leave)

        # Spinner label (hidden initially)
        self.spinner_label = ttk.Label(self, text="⏳ Aguardando confirmação...", font=("Segoe UI", 10), style="PlanSelector.TLabel")
        self.spinner_label.grid(row=len(config) + 2, column=0, columnspan=2, pady=(0, 5), sticky="ew")
        self.spinner_label.grid_remove()  # Hide initially

        self.hint = ttk.Label(
            self,
            text=_("Tudo incluso: suporte prioritário, limites maiores e segurança Stripe."),
            font=("Segoe UI", 9),
            foreground="#64748B",
            wraplength=320,
            style="PlanSelector.TLabel",
        )
        self.hint.grid(row=len(config) + 2, column=0, columnspan=2, sticky="w")

    def _get_button_text(self):
        if self.is_checkout_active:
            return _("⏳ Checkout em andamento...")
        base = _("Upgrade para PRO")
        if self.is_guest_mode:
            base += " (necessário criar conta)"
        return base

    def set_checkout_active(self, active: bool):
        """Called by parent during polling."""
        self.is_checkout_active = active
        is_disabled = active or self.is_guest_mode
        self.btn_upgrade.configure(
            text=self._get_button_text(),
            command=self._on_upgrade_clicked if not is_disabled else None,
            state="disabled" if is_disabled else "normal",
            bg="#2563EB" if not is_disabled else "#9CA3AF",
            cursor="hand2" if not is_disabled else "arrow",
        )
        if active:
            self.spinner_label.grid()
        else:
            self.spinner_label.grid_remove()
        if self.on_checkout_state_change:
            self.on_checkout_state_change(active)

    def _on_button_hover(self, event):
        # Only hover if not guest and not checkout active
        if not self.is_guest_mode and not self.is_checkout_active and self.btn_upgrade["state"] == "normal":
            self.btn_upgrade.config(bg="#1D4ED8")  # Hover

    def _on_button_leave(self, event):
        # Only change color back if not guest and not checkout active
        if not self.is_guest_mode and not self.is_checkout_active:
            self.btn_upgrade.config(bg="#2563EB")

    def _on_upgrade_clicked(self):
        """Handle upgrade button click com suporte a checkout Stripe."""
        selected = self.plan_var.get()
        
        # Log da seleção
        logger.info("User selected plan: %s", selected)
        
        if self.on_upgrade:
            self.on_upgrade(selected, billing_service=self.billing_service)
            self.set_checkout_active(True) # Self-disable immediately
    
    def get_currency(self) -> str:
        """Retorna moeda detectada para este frame."""
        return self.currency
    
    def get_billing_country(self) -> Optional[str]:
        """Retorna país de cobrança se disponível via BillingCountryService."""
        if self.billing_service:
            try:
                return self.billing_service.billing_country
            except Exception:
                return None
        return None

    def _on_detection_timeout(self):
        """Callback chamado se a detecção demorar muito (fallback)."""
        if self.detection_completed:
            logger.debug("Detection already completed, ignoring timeout")
            return
            
        logger.warning("⏱️ Currency detection timed out, using fallback USD")
        self._on_currency_detected("USD")

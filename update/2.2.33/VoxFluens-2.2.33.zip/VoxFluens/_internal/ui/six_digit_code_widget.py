"""
Widget reutilizável para entrada de código de 6 dígitos.
Usado em verificação de email e reset de senha.
"""
import re
import tkinter as tk
from tkinter import ttk


class SixDigitCodeWidget:
    """Widget com 6 campos individuais para entrada de código numérico."""
    
    def __init__(self, parent_frame, on_complete=None, font_size=20):
        """
        Inicializa o widget de 6 dígitos.
        
        Args:
            parent_frame: Frame pai onde o widget será inserido
            on_complete: Callback chamado quando todos os 6 dígitos são preenchidos
            font_size: Tamanho da fonte dos dígitos
        """
        self.parent = parent_frame
        self.on_complete = on_complete
        self.font_size = font_size
        
        # Frame container para os dígitos
        self.digits_frame = ttk.Frame(parent_frame)
        self.digits_frame.pack(pady=(0, 12))
        
        # 6 campos individuais
        self.digit_entries = []
        for i in range(6):
            digit_entry = tk.Entry(
                self.digits_frame,
                width=3,
                font=("Segoe UI", font_size, "bold"),
                justify=tk.CENTER,
                borderwidth=1,
                relief=tk.SOLID,
                bg="#F8FAFC",
                fg="#1E293B",
                highlightthickness=0
            )
            digit_entry.pack(side=tk.LEFT, padx=3, ipady=8, ipadx=4)
            
            # Bindings para validação e navegação
            digit_entry.bind("<KeyRelease>", lambda e, idx=i: self._on_digit_key(idx, e))
            digit_entry.bind("<Key>", lambda e, idx=i: self._on_digit_key_down(idx, e))
            digit_entry.bind("<BackSpace>", lambda e, idx=i: self._on_backspace(idx, e))
            digit_entry.bind("<Left>", lambda e, idx=i: self._on_arrow_left(idx, e))
            digit_entry.bind("<Right>", lambda e, idx=i: self._on_arrow_right(idx, e))
            digit_entry.bind("<Control-v>", lambda e, idx=i: self._on_paste(idx, e))
            digit_entry.bind("<Command-v>", lambda e, idx=i: self._on_paste(idx, e))  # Mac
            
            self.digit_entries.append(digit_entry)
    
    def focus_first(self):
        """Coloca o foco no primeiro campo de dígito."""
        if self.digit_entries:
            self.digit_entries[0].focus()
    
    def get_code(self):
        """Retorna o código completo de 6 dígitos como string."""
        return "".join(entry.get() for entry in self.digit_entries)
    
    def clear(self):
        """Limpa todos os campos de dígitos."""
        for entry in self.digit_entries:
            entry.delete(0, tk.END)
        self.focus_first()
    
    def set_code(self, code):
        """
        Define o código nos campos.
        
        Args:
            code: String com 6 dígitos
        """
        code = str(code).strip()
        if len(code) == 6 and code.isdigit():
            for i, digit in enumerate(code):
                self.digit_entries[i].delete(0, tk.END)
                self.digit_entries[i].insert(0, digit)
    
    def is_complete(self):
        """Verifica se todos os 6 dígitos foram preenchidos."""
        code = self.get_code()
        return len(code) == 6 and code.isdigit()
    
    def _on_digit_key(self, idx, event):
        """Handler para KeyRelease - valida e avança para próximo campo."""
        entry = self.digit_entries[idx]
        content = entry.get()
        
        # Permitir apenas dígitos
        if content and not content.isdigit():
            entry.delete(0, tk.END)
            return
        
        # Limitar a 1 dígito
        if len(content) > 1:
            entry.delete(1, tk.END)
            content = entry.get()
        
        # Avançar para próximo campo se tiver conteúdo
        if content and idx < 5:
            self.digit_entries[idx + 1].focus()
            self.digit_entries[idx + 1].icursor(tk.END)
        
        # Verificar se está completo
        if self.is_complete() and self.on_complete:
            self.on_complete()
    
    def _on_digit_key_down(self, idx, event):
        """Handler para Key - previne entrada de não-dígitos."""
        # Permitir teclas de controle
        if event.keysym in ('BackSpace', 'Delete', 'Left', 'Right', 'Tab'):
            return
        
        # Bloquear se já tem 1 dígito
        entry = self.digit_entries[idx]
        if len(entry.get()) >= 1:
            return 'break'
        
        # Permitir apenas dígitos
        if not event.char.isdigit():
            return 'break'
    
    def _on_backspace(self, idx, event):
        """Handler para BackSpace - volta para campo anterior se vazio."""
        entry = self.digit_entries[idx]
        if not entry.get() and idx > 0:
            self.digit_entries[idx - 1].focus()
            self.digit_entries[idx - 1].icursor(tk.END)
    
    def _on_arrow_left(self, idx, event):
        """Handler para seta esquerda - move para campo anterior."""
        if idx > 0:
            self.digit_entries[idx - 1].focus()
            self.digit_entries[idx - 1].icursor(tk.END)
            return 'break'
    
    def _on_arrow_right(self, idx, event):
        """Handler para seta direita - move para próximo campo."""
        if idx < 5:
            self.digit_entries[idx + 1].focus()
            self.digit_entries[idx + 1].icursor(tk.END)
            return 'break'
    
    def _on_paste(self, idx, event):
        """Handler para Ctrl+V/Cmd+V - extrai dígitos e preenche campos."""
        try:
            pasted = self.parent.clipboard_get()
            # Extrair apenas dígitos
            digits = re.sub(r"\D", "", pasted)
            
            if len(digits) >= 6:
                # Preencher os 6 campos
                for i in range(6):
                    self.digit_entries[i].delete(0, tk.END)
                    self.digit_entries[i].insert(0, digits[i])
                
                # Focar no último campo
                self.digit_entries[5].focus()
                
                # Verificar se está completo
                if self.is_complete() and self.on_complete:
                    self.on_complete()
            
            return 'break'
        except:
            pass

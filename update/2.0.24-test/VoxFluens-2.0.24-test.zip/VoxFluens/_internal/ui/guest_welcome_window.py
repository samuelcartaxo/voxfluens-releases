import tkinter as tk
from tkinter import ttk, messagebox
import requests
import threading
import i18n
from PIL import Image, ImageTk
import os
import textwrap
import sys
import config_manager
from ui.welcome_window import WelcomeWindow
import queue


def _call_toplevel_method(instance, method_name, *args, **kwargs):
    method = getattr(super(type(instance), instance), method_name, None)
    if callable(method):
        return method(*args, **kwargs)

_ = i18n._

class GuestWelcomeWindow(tk.Toplevel):
    """
    Janela de boas-vindas para usuários Guest retornando.

    Esta janela aparece quando um usuário Guest com sessão válida retorna ao app,
    oferecendo opções para continuar como Guest, fazer upgrade ou criar conta,
    mantendo o device_id existente para preservar limites.
    """

    def __init__(self, parent, on_continue_guest, on_create_account, on_upgrade_pro, on_login_success=None):
        """Inicializa a janela de boas-vindas para Guest retornando."""
        # If parent is not a real tkinter root/toplevel (e.g., Mock in tests),
        # create as top-level without a parent to avoid Tk internals errors.
        # If the given parent looks like a Tk widget (has 'tk' attribute), keep it, else detach
        # Store the passed parent for later use (destroy or other callbacks) but avoid
        # passing mock objects or non-Tk parents to super().__init__ to avoid Tk internals errors
        self._passed_parent = parent
        super().__init__(None)
        # Criar inicialmente escondida para evitar flicker causado por WM
        self.withdraw()

        # Callbacks
        self.on_continue_guest = on_continue_guest
        self.on_create_account = on_create_account
        self.on_upgrade_pro = on_upgrade_pro
        self.on_login_success_callback = on_login_success

        # Estado da sessão Guest
        self.guest_session_valid = False
        self.device_id = None
        self.session_data = None

        # Configurações básicas
        self.title(_("VoxFluens"))
        self.parent = parent

        # Fundo com gradiente sutil
        self.configure(bg="#FFFFFF")

        # Não usar overrideredirect - manter decoração padrão para simplicidade e compatibilidade
        self.overrideredirect(False)
        self.resizable(False, False)

        # Estado interno
        self.queue = queue.Queue()

        # Validar sessão Guest antes de mostrar UI
        self._validate_guest_session()

        # Estilização e UI
        self._configure_styles()
        self.setup_ui()

        # Centralizar e mostrar sem flicker: calcular geometria enquanto oculta,
        # aplicar e então mostrar com uma transição alfa.
        try:
            # Simples: sem transparência para compatibilidade
            # Centraliza e aplica geometry (retries internos)
            self._center_window()
            # Apresenta janela ao usuário com fade-in
            try:
                self.deiconify()
                self.lift()
                self.focus_force()
                # Sem fade-in: apenas deiconify
                # Sem override-redirect reativação; mantemos decoração padrão
            except Exception:
                # Se deiconify falhar, tentar mostrar normalmente
                try:
                    self.deiconify()
                except Exception:
                    pass
            # Não refazer reposicionamento para evitar flicker - manter posição aplicada
        except Exception as e:
            print(f"[LOG] Falha ao preparar GuestWelcomeWindow de maneira oculta: {e}")

        # Bindings
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._bind_events()

        # Inicia processamento da fila
        self.process_queue()

    def geometry(self, *args, **kwargs):
        return _call_toplevel_method(self, "geometry", *args, **kwargs)

    def resizable(self, *args, **kwargs):
        return _call_toplevel_method(self, "resizable", *args, **kwargs)

    def configure(self, *args, **kwargs):
        return _call_toplevel_method(self, "configure", *args, **kwargs)

    def title(self, *args, **kwargs):
        return _call_toplevel_method(self, "title", *args, **kwargs)

    def protocol(self, *args, **kwargs):
        return _call_toplevel_method(self, "protocol", *args, **kwargs)

    def lift(self, *args, **kwargs):
        return _call_toplevel_method(self, "lift", *args, **kwargs)

    def focus_force(self, *args, **kwargs):
        return _call_toplevel_method(self, "focus_force", *args, **kwargs)

    def overrideredirect(self, *args, **kwargs):
        return _call_toplevel_method(self, "overrideredirect", *args, **kwargs)

    def _configure_styles(self):
        """Configura estilos ttk modernos, copiados da welcome window."""
        style = ttk.Style(self)
        style.theme_use("clam")

        self.colors = {
            "bg": "#FFFFFF",
            "primary": "#2563EB",
            "primary_hover": "#1D4ED8",
            "text_main": "#1E293B",
            "text_light": "#64748B",
            "error": "#EF4444",
            "border": "#E2E8F0"
        }

        style.configure(".", background=self.colors["bg"], font=("Segoe UI", 10))
        style.configure("TFrame", background=self.colors["bg"])
        style.configure("Card.TFrame", background="#F8FAFC", relief="solid", borderwidth=1, bordercolor=self.colors["border"])
        style.configure("Header.TLabel", font=("Segoe UI", 18, "bold"), foreground=self.colors["primary"])
        style.configure("Subheader.TLabel", font=("Segoe UI", 11), foreground=self.colors["text_light"])
        style.configure("Body.TLabel", font=("Segoe UI", 10), foreground=self.colors["text_main"])
        style.configure("Link.TLabel", font=("Segoe UI", 10, "underline"), foreground=self.colors["primary"])
        style.configure("Error.TLabel", font=("Segoe UI", 9), foreground=self.colors["error"])

        # Card label styles to blend with Card.TFrame background
        style.configure("CardHeader.TLabel", background="#F8FAFC", font=("Segoe UI", 11, "bold"), foreground=self.colors["primary"])
        style.configure("CardBody.TLabel", background="#F8FAFC", font=("Segoe UI", 9), foreground=self.colors["text_main"])
        style.configure("CardLink.TLabel", background="#F8FAFC", font=("Segoe UI", 9, "underline"), foreground=self.colors["primary"])

        # Left card (PRO benefits) uses a persistent light-blue background
        left_card_bg = "#F1F6FF"
        style.configure("LeftCard.TFrame", background=left_card_bg, relief="solid", borderwidth=1, bordercolor=self.colors["border"])
        style.configure("LeftCardHeader.TLabel", background=left_card_bg, font=("Segoe UI", 11, "bold"), foreground=self.colors["primary"])
        style.configure("LeftCardBody.TLabel", background=left_card_bg, font=("Segoe UI", 9), foreground=self.colors["text_main"])
        style.configure("LeftCardLink.TLabel", background=left_card_bg, font=("Segoe UI", 9, "underline"), foreground=self.colors["primary"])

        style.configure("Accent.TButton",
            font=("Segoe UI", 10, "bold"),
            foreground="#FFFFFF",
            background=self.colors["primary"],
            borderwidth=0,
            padding=(20, 10)
        )
        style.map("Accent.TButton",
            background=[("active", self.colors["primary_hover"]), ("disabled", self.colors["text_light"])],
            foreground=[("disabled", "#F1F5F9")]
        )

        style.configure("Secondary.TButton",
            font=("Segoe UI", 10),
            foreground=self.colors["primary"],
            background="#FFFFFF",
            borderwidth=1,
            bordercolor=self.colors["border"],
            padding=(15, 8)
        )
        style.map("Secondary.TButton",
            background=[("active", "#F8FAFC")]
        )

        # Estilo para botão outline (signup)
        style.configure("Outline.TButton",
            font=("Segoe UI", 10),
            foreground=self.colors["primary"],
            background="#FFFFFF",
            borderwidth=2,
            relief="solid",
            bordercolor=self.colors["primary"],
            padding=(15, 8)
        )
        style.map("Outline.TButton",
            background=[("active", self.colors["primary"]), ("pressed", self.colors["primary"])],
            foreground=[("active", "#FFFFFF"), ("pressed", "#FFFFFF")],
            bordercolor=[("active", self.colors["primary"])]
        )

        style.configure("TEntry",
            fieldbackground="#F8FAFC",
            borderwidth=1,
            relief="solid",
            padding=5,
            bordercolor=self.colors["border"]
        )

        style.configure("Focus.TEntry",
            fieldbackground="#F8FAFC",
            borderwidth=2,
            relief="solid",
            padding=5,
            bordercolor=self.colors["primary"]
        )

    def setup_ui(self):
        """Configura a interface da janela."""
        # Container principal
        self.main_container = ttk.Frame(self, padding=30)
        self.main_container.pack(fill="both", expand=True)

        # Header
        self._setup_header()

        # Conteúdo principal
        self._setup_content()

        # Formulário de login (inicialmente oculto)
        self._setup_login_form()

        # Status
        self.lbl_status = ttk.Label(self.main_container, text="", style="Error.TLabel", wraplength=350)
        self.lbl_status.pack(pady=(15, 0))

    def _setup_header(self):
        """Configura o cabeçalho da janela."""
        header_frame = ttk.Frame(self.main_container)
        header_frame.pack(fill="x", pady=(0, 20))

        # Logo
        try:
            if hasattr(sys, '_MEIPASS'):
                logo_path = os.path.join(sys._MEIPASS, "voxfluens_icon64x64.ico")
            else:
                logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "voxfluens_icon64x64.ico")
                if not os.path.exists(logo_path):
                    logo_path = "voxfluens_icon64x64.ico"

            if os.path.exists(logo_path):
                pil_image = Image.open(logo_path)
                pil_image = pil_image.resize((64, 64), Image.Resampling.LANCZOS)
                self.logo_img = ImageTk.PhotoImage(pil_image)
                logo_label = tk.Label(header_frame, image=self.logo_img, bg=self.colors["bg"])
                logo_label.pack(pady=(0, 10))
        except Exception as e:
            print(f"Logo load error: {e}")

        # Título
        ttk.Label(header_frame, text=_("Bem-vindo de volta!"), style="Header.TLabel", justify="center", anchor="center").pack(fill="x", pady=(0, 8))

        # Subtítulo
        ttk.Label(header_frame, text=_("Você está usando o VoxFluens como Visitante"), style="Subheader.TLabel", justify="center", anchor="center", wraplength=380).pack(fill="x")

    def _setup_content(self):
        """Configura o conteúdo principal."""
        content_frame = ttk.Frame(self.main_container)
        content_frame.pack(fill="x", pady=10)

        # Botão principal - Continuar como Guest
        self.btn_continue_guest = ttk.Button(content_frame,
            text=_("🚀 Continuar como Visitante"),
            command=self._on_continue_guest,
            style="Accent.TButton",
            cursor="hand2"
        )
        self.btn_continue_guest.pack(fill="x", pady=(0, 12))

        # Texto explicativo
        guest_info_label = ttk.Label(content_frame,
            text=_("guest_trial_pitch"),
            style="Subheader.TLabel",
        )
        guest_info_label.pack(pady=(0, 20))

        # Seção PRO
        self._setup_pro_section(content_frame)

        # Botões secundários
        self._setup_action_buttons(content_frame)

    def _setup_pro_section(self, parent):
        """Configura a seção de benefícios PRO."""
        pro_benefits_frame = ttk.Frame(parent, style="LeftCard.TFrame")
        pro_benefits_frame.pack(fill="x", pady=(0, 20))

        # Título
        pro_title_label = ttk.Label(pro_benefits_frame,
            text=_("✨ Desbloqueie o Potencial Completo"),
            style="LeftCardHeader.TLabel",
        )
        pro_title_label.pack(anchor="w", pady=(10, 5), padx=15)

        # Benefícios
        benefits_text = "• Transcrições ilimitadas\n• Suporte prioritário\n• Sem anúncios\n• Dashboard com limites de uso (diário/semana/mês) e visualização de consumo"

        pro_benefits_label = ttk.Label(pro_benefits_frame,
            text=benefits_text,
            style="LeftCardBody.TLabel",
            justify="left",
            anchor="w"
        )
        pro_benefits_label.pack(anchor="w", padx=15, pady=(0, 10))

        # Link de upgrade
        upgrade_btn = ttk.Label(pro_benefits_frame,
            text=_("Fazer upgrade para PRO →"),
            style="LeftCardLink.TLabel",
        )
        upgrade_btn.pack(anchor="e", padx=15, pady=(0, 10))
        upgrade_btn.bind("<Button-1>", lambda e: self._on_upgrade_pro())
        upgrade_btn.configure(cursor="hand2")

    def _setup_action_buttons(self, parent):
        """Configura os botões de ação secundários."""
        actions_frame = ttk.Frame(parent)
        actions_frame.pack(fill="x", pady=(10, 0))

        # Botões de ação
        buttons_frame = ttk.Frame(actions_frame)
        buttons_frame.pack(fill="x")

        # Botão criar conta
        self.btn_create_account = ttk.Button(buttons_frame,
            text=_("👤 Criar conta gratuita"),
            command=self._on_create_account,
            style="Outline.TButton",
            cursor="hand2"
        )
        self.btn_create_account.pack(fill="x", pady=(0, 8))

        # Botão fazer login
        self.btn_login = ttk.Button(buttons_frame,
            text=_("🔑 Já tenho conta - Fazer Login"),
            command=lambda: self._open_full_welcome(mode="login"),
            style="Secondary.TButton",
            cursor="hand2"
        )
        self.btn_login.pack(fill="x", pady=(0, 10))

        # Botão fechar
        self.btn_close = ttk.Label(actions_frame,
            text=_("Fechar"),
            style="Body.TLabel",
        )
        self.btn_close.pack(anchor="center")
        self.btn_close.bind("<Button-1>", lambda e: self.on_close())
        self.btn_close.configure(cursor="hand2")

    def _setup_login_form(self):
        """Configura o formulário de login (inicialmente oculto)."""
        self.login_form_frame = ttk.Frame(self.main_container)

        # Título do formulário
        ttk.Label(self.login_form_frame, text=_("Fazer Login"), style="Header.TLabel", justify="center", anchor="center").pack(fill="x", pady=(0, 15))

        # Campo email
        ttk.Label(self.login_form_frame, text=_("Email"), style="Body.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_login_email = ttk.Entry(self.login_form_frame, font=("Segoe UI", 11))
        self.entry_login_email.pack(fill="x", pady=(0, 10))
        self._bind_focus_highlight(self.entry_login_email)

        # Campo senha
        ttk.Label(self.login_form_frame, text=_("Senha"), style="Body.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_login_password = ttk.Entry(self.login_form_frame, show="*", font=("Segoe UI", 11))
        self.entry_login_password.pack(fill="x", pady=(0, 15))
        self._bind_focus_highlight(self.entry_login_password)

        # Botões
        buttons_frame = ttk.Frame(self.login_form_frame)
        buttons_frame.pack(fill="x")

        self.btn_perform_login = ttk.Button(buttons_frame, text=_("Entrar"), command=self.perform_login, style="Accent.TButton", cursor="hand2")
        self.btn_perform_login.pack(fill="x", pady=(0, 8))

        self.btn_login_back = ttk.Label(buttons_frame, text=_("Voltar"), style="Body.TLabel")
        self.btn_login_back.pack(anchor="center")
        self.btn_login_back.bind("<Button-1>", lambda e: self.hide_login_form())
        self.btn_login_back.configure(cursor="hand2")

    def _validate_guest_session(self):
        """
        Valida se há uma sessão Guest existente e válida.
        Se token válido, continua com sessão carregada. Se 401, refaz bootstrap.
        """
        try:
            session_data = config_manager.get_session_data()

            # Verifica se há sessão ativa que seja Guest
            if (config_manager.is_session_active() and
                session_data.get("is_guest") and
                session_data.get("access_token")):

                # Tenta validar token com backend (request simples)
                token = session_data["access_token"]
                device_id = config_manager.get_or_create_device_id()

                headers = {"Authorization": f"Bearer {token}"}

                # Validação simples do token
                response = requests.get(
                    f"{config_manager.API_BASE_URL}/api/v1/users/me/dashboard",
                    headers=headers,
                    timeout=5
                )

                if response.status_code == 200:
                    # Sessão válida - usar sessão carregada (server_config já está em memória)
                    self.guest_session_valid = True
                    self.device_id = device_id
                    self.session_data = session_data
                    print(f"[LOG] Sessão Guest validada - device_id: {device_id[:8]}...")
                    return
                elif response.status_code == 401:
                    # Token expirado - refazer bootstrap
                    print("[LOG] Token Guest expirado - refazendo bootstrap")
                    self._refresh_guest_session()
                    return
                else:
                    # Outro erro - limpar sessão
                    print(f"[LOG] Erro na validação Guest: {response.status_code}")
                    config_manager.clear_session_data()

            else:
                print("[LOG] Nenhuma sessão Guest ativa encontrada")

        except Exception as e:
            print(f"[LOG] Erro ao validar sessão Guest: {e}")
            # Em caso de erro, limpar sessão para evitar inconsistências
            config_manager.clear_session_data()

        # Se chegou aqui, não há sessão válida
        self.guest_session_valid = False
        self.device_id = None
        self.session_data = None

    def _refresh_guest_session(self):
        """
        Refaz bootstrap Guest quando token expirou (401).
        """
        try:
            device_id = config_manager.get_or_create_device_id()
            cfg = config_manager.load_config()
            ui_language = cfg.get("language", "pt-BR")

            response = requests.post(
                f"{config_manager.API_BASE_URL}/api/v1/bootstrap/guest",
                json={"ui_language": ui_language, "device_id": device_id},
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                backend_device_id = data.get("device_id")
                if backend_device_id:
                    config_manager.update_device_id(backend_device_id)

                # Atualizar sessão com dados frescos do bootstrap
                access_token = data.get("access_token")
                user = data.get("user", {})
                server_config = {
                    "transcription": data.get("transcription"),
                    "work": data.get("work"),
                    "image": data.get("image")
                }
                limits = data.get("limits", {})

                config_manager.set_session_data(
                    access_token=access_token,
                    user_id=user.get("id"),
                    server_config=server_config,
                    limits=limits,
                    is_guest=True,
                    user_email=None,
                    user_name=None,
                    user_plan=None,
                    user_language=user.get("language"),
                    user_data=user,
                    billing={}
                )

                self.guest_session_valid = True
                self.device_id = device_id
                self.session_data = config_manager.get_session_data()
                print(f"[LOG] Sessão Guest renovada via bootstrap - device_id: {device_id[:8]}...")
            else:
                print(f"[LOG] Falha ao renovar sessão Guest: {response.status_code}")
                config_manager.clear_session_data()
                self.guest_session_valid = False
                self.device_id = None
                self.session_data = None

        except Exception as e:
            print(f"[LOG] Erro ao renovar sessão Guest: {e}")
            config_manager.clear_session_data()
            self.guest_session_valid = False
            self.device_id = None
            self.session_data = None

    def _center_window(self):
        """Centraliza a janela na tela com heurísticas de UX e suporte multi-monitor.

        Estratégia:
        - Determinar o monitor ativo (onde o cursor está) usando ctypes (Windows) se disponível.
        - Calcular centro levando em conta um offset vertical leve para melhor UX.
        - Tentar realocar a janela múltiplas vezes (após layout) para evitar casos onde a janela seja reposicionada pelo WM.
        """
        try:
            # Forçar layout inicial
            self.update_idletasks()
            self.update()

            # Medidas da janela requerida
            req_w = self.winfo_reqwidth()
            req_h = self.winfo_reqheight()
            target_width = max(380, req_w + 20)
            target_height = max(450, req_h + 20)

            # Tenta obter monitor ativo (cursor) via ctypes (Windows); fallback para Tkinter primary
            left, top, screen_width, screen_height = self._get_active_monitor_rect()
            print(f"[LOG] GuestWelcomeWindow monitor rect: left={left},top={top},w={screen_width},h={screen_height}")

            # Centraliza horizontalmente no monitor selecionado
            x = max(left, left + ((screen_width - target_width) // 2))

            # Offset vertical leve para cima para melhor UX em monitores altos
            vertical_offset = int(screen_height * 0.1)
            y = max(top, top + ((screen_height - target_height) // 2) - vertical_offset)
            y = max(top, min(y, top + (screen_height - target_height)))

            # Apply geometry
            self.geometry(f"{int(target_width)}x{int(target_height)}+{x}+{y}")
            print(f"[LOG] GuestWelcomeWindow geometry set: {int(target_width)}x{int(target_height)}+{x}+{y} (req {req_w}x{req_h})")

            # Força o foco e coloca temporariamente acima: aumenta chance de posicionamento correto
            try:
                self.attributes("-topmost", True)
                self.lift()
                self.focus_force()
                # remove topmost após curto delay para comportamento normal do WM
                self.after(300, lambda: self.attributes("-topmost", False))
            except Exception:
                # Não crítico se falhar em plataformas sem suporte
                pass

            # Em alguns ambientes o WM pode reposicionar janelas; reforça o centramento após layout final
            self.after(150, lambda: self._center_window_once(target_width, target_height, left, top, screen_width, screen_height))
        except Exception as e:
            print(f"[LOG] Erro ao centralizar GuestWelcomeWindow: {e}")

    def _center_window_once(self, target_width, target_height, left, top, screen_width, screen_height):
        """Realiza um centramento único usando os valores já calculados."""
        try:
            x = max(left, left + ((screen_width - target_width) // 2))
            vertical_offset = int(screen_height * 0.1)
            y = max(top, top + ((screen_height - target_height) // 2) - vertical_offset)
            y = max(top, min(y, top + (screen_height - target_height)))
            self.geometry(f"{int(target_width)}x{int(target_height)}+{x}+{y}")
        except Exception:
            pass

    def _get_active_monitor_rect(self):
        """Retorna (left, top, width, height) do monitor onde o cursor está.

        Faz fallback para monitor primário via Tkinter se ctypes falhar.
        """
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            # Estruturas e funções
            pt = wintypes.POINT()
            user32.GetCursorPos(ctypes.byref(pt))

            MONITOR_DEFAULTTONEAREST = 2
            monitor = user32.MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST)
            if not monitor:
                raise Exception("Monitor não encontrado")

            class MONITORINFO(ctypes.Structure):
                _fields_ = [('cbSize', wintypes.DWORD),
                            ('rcMonitor', wintypes.RECT),
                            ('rcWork', wintypes.RECT),
                            ('dwFlags', wintypes.DWORD)]

            info = MONITORINFO()
            info.cbSize = ctypes.sizeof(MONITORINFO)
            res = user32.GetMonitorInfoW(monitor, ctypes.byref(info))
            if not res:
                raise Exception("GetMonitorInfoW falhou")
            rc = info.rcMonitor
            left, top = rc.left, rc.top
            width = rc.right - rc.left
            height = rc.bottom - rc.top
            return left, top, width, height
        except Exception:
            # Fallback: usar screen primário do Tk
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            return 0, 0, sw, sh

    def _bind_events(self):
        """Configura os bindings de eventos."""
        self.bind("<<GuestSessionCreated>>", self._on_guest_session_created)
        self.bind("<<GuestSessionError>>", self._on_guest_session_error)
        self.bind("<<LoginSuccess>>", self._on_login_success)
        self.bind("<<LoginError>>", self._on_login_error)

        # Adicionar navegação por teclado sem afetar o visual
        self._setup_keyboard_navigation()

    def _setup_keyboard_navigation(self):
        """Configura navegação por teclado mantendo o design visual intacto."""
        # Bindings globais para navegação por teclado
        self.bind('<Return>', self._handle_enter_key)
        self.bind('<KP_Enter>', self._handle_enter_key)  # NumPad Enter
        self.bind('<Escape>', self._handle_escape_key)

        # Bindings específicos nos campos quando eles existem
        self._bind_field_events()

    def _bind_field_events(self):
        """Configura eventos específicos nos campos de entrada."""
        # Bindings para campos de login quando existem
        if hasattr(self, 'entry_login_email'):
            self.entry_login_email.bind('<Return>', lambda e: self._handle_field_enter('email'))
        if hasattr(self, 'entry_login_password'):
            self.entry_login_password.bind('<Return>', lambda e: self._handle_field_enter('password'))

    def _handle_enter_key(self, event):
        """Gerencia tecla Enter baseada no widget ativo."""
        current = self.focus_get()

        # Se estamos em um campo de entrada, delegar para o handler específico
        if hasattr(current, 'get'):  # É um Entry widget
            if current == getattr(self, 'entry_login_password', None):
                self._handle_field_enter('password')()
            else:
                # Para outros campos, mover para o próximo campo lógico
                self._move_to_next_field(current)
        else:
            # Se estamos em um botão, executar sua ação
            if hasattr(current, 'invoke'):
                current.invoke()

        return 'break'  # Previne comportamento padrão

    def _handle_field_enter(self, field_type):
        """Retorna função handler específica para cada tipo de campo."""
        def handler():
            if field_type == 'email':
                # Enter no email: ir para senha
                if hasattr(self, 'entry_login_password'):
                    self.entry_login_password.focus_set()
            elif field_type == 'password':
                # Enter na senha: fazer login
                if hasattr(self, 'perform_login'):
                    self.perform_login()

        return handler

    def _move_to_next_field(self, current_field):
        """Move o foco para o próximo campo lógico."""
        if current_field == getattr(self, 'entry_login_email', None):
            if hasattr(self, 'entry_login_password'):
                self.entry_login_password.focus_set()

    def _handle_escape_key(self, event):
        """Gerencia tecla Escape para fechar formulários ou voltar."""
        # Se estamos no formulário de login, voltar para a tela inicial
        if hasattr(self, 'hide_login_form'):
            self.hide_login_form()
        else:
            # Caso contrário, fechar a janela
            self.on_close()

        return 'break'

    def _bind_focus_highlight(self, entry_widget):
        """Configura highlight visual nos campos de entrada."""
        def on_focus_in(e):
            e.widget.configure(style="Focus.TEntry")
        def on_focus_out(e):
            e.widget.configure(style="TEntry")
        entry_widget.bind("<FocusIn>", on_focus_in)
        entry_widget.bind("<FocusOut>", on_focus_out)

    def _restore_window_position(self):
        """Calcula dimensões e restaura posição da janela."""
        self.update_idletasks()  # Força cálculo de tamanho dos widgets

        target_width = 420
        req_height = self.main_container.winfo_reqheight()
        target_height = req_height + 10

        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        x = None
        y = None

        try:
            cfg = config_manager.load_config()
            saved_x = cfg.get("guest_welcome_x")
            saved_y = cfg.get("guest_welcome_y")

            # Validação básica de limites de tela
            if saved_x is not None and saved_y is not None:
                if 0 <= saved_x < (screen_width - 50) and 0 <= saved_y < (screen_height - 50):
                    x = saved_x
                    y = saved_y
        except Exception:
            pass

        if x is None or y is None:
            x = max(0, (screen_width - target_width) // 2)
            y = max(0, (screen_height - target_height) // 2)

        # Aplica a geometria
        self.geometry(f"{target_width}x{target_height}+{x}+{y}")

    def _save_window_position(self):
        """Salva a posição atual da janela."""
        try:
            cfg = config_manager.load_config()
            cfg["guest_welcome_x"] = self.winfo_x()
            cfg["guest_welcome_y"] = self.winfo_y()
            config_manager.save_config(cfg)
        except Exception:
            pass

    def set_loading(self, is_loading, message=""):
        """Define o estado de loading da interface."""
        if is_loading:
            self.lbl_status.configure(text=message, foreground=self.colors["primary"])
            self.config(cursor="watch")
            # Desabilita botões principais
            if hasattr(self, 'btn_continue_guest'): self.btn_continue_guest.configure(state="disabled")
            if hasattr(self, 'btn_create_account'): self.btn_create_account.configure(state="disabled")
            if hasattr(self, 'btn_login'): self.btn_login.configure(state="disabled")
            if hasattr(self, 'btn_perform_login'): self.btn_perform_login.configure(state="disabled")
        else:
            self.lbl_status.configure(text="", foreground=self.colors["text_main"])
            self.config(cursor="")
            # Reabilita botões principais
            if hasattr(self, 'btn_continue_guest'): self.btn_continue_guest.configure(state="normal")
            if hasattr(self, 'btn_create_account'): self.btn_create_account.configure(state="normal")
            if hasattr(self, 'btn_login'): self.btn_login.configure(state="normal")
            if hasattr(self, 'btn_perform_login'): self.btn_perform_login.configure(state="normal")

    def process_queue(self):
        """Processa a fila de eventos."""
        try:
            while True:
                event_name = self.queue.get_nowait()
                if hasattr(self, "winfo_exists") and not self.winfo_exists():
                    return
                self.event_generate(event_name)
        except queue.Empty:
            pass
        if hasattr(self, "winfo_exists") and self.winfo_exists():
            self.after(100, self.process_queue)

    def _on_continue_guest(self):
        """Callback para continuar como guest - reaproveita sessão existente."""
        if self.guest_session_valid and self.session_data:
            # Sessão válida - apenas continuar
            print("[LOG] Continuando com sessão Guest existente")
            if self.on_continue_guest:
                self.on_continue_guest()
            try:
                self._safe_destroy()
            except Exception:
                pass
        else:
            # Não deveria chegar aqui se validação funcionou, mas fallback
            print("[LOG] Tentando criar nova sessão Guest")
            self._create_new_guest_session()

    def _create_new_guest_session(self):
        """Cria uma nova sessão Guest (fallback)."""
        def guest_thread():
            try:
                device_id = config_manager.get_or_create_device_id()
                cfg = config_manager.load_config()
                ui_language = cfg.get("language", "pt-BR")

                response = requests.post(
                    f"{config_manager.API_BASE_URL}/api/v1/bootstrap/guest",
                    json={"ui_language": ui_language, "device_id": device_id},
                    timeout=10
                )

                if response.status_code == 200:
                    data = response.json()
                    backend_device_id = data.get("device_id")
                    if backend_device_id:
                        config_manager.update_device_id(backend_device_id)

                    # Atualizar sessão
                    access_token = data.get("access_token")
                    user = data.get("user", {})
                    server_config = {
                        "transcription": data.get("transcription"),
                        "work": data.get("work"),
                        "image": data.get("image")
                    }
                    limits = data.get("limits", {})

                    config_manager.set_session_data(
                        access_token=access_token,
                        user_id=user.get("id"),
                        server_config=server_config,
                        limits=limits,
                        is_guest=True,
                        user_email=None,
                        user_name=None,
                        user_plan=None,
                        user_language=user.get("language"),
                        user_data=user,
                        billing={}
                    )

                    self.queue.put("<<GuestSessionCreated>>")
                else:
                    error_msg = f"Erro ao criar sessão Guest: {response.status_code}"
                    self.thread_error_msg = error_msg
                    self.queue.put("<<GuestSessionError>>")

            except Exception as e:
                self.thread_error_msg = str(e)
                self.queue.put("<<GuestSessionError>>")

        # Executar em thread
        threading.Thread(target=guest_thread, daemon=True).start()

    def _open_full_welcome(self, mode="login"):
        """
        Abre a WelcomeWindow completa no modo solicitado (login/signup) e fecha esta janela.
        Evitamos janelas sobrepostas para reduzir fricção e confusão.
        """
        try:
            parent = self._passed_parent if isinstance(self._passed_parent, tk.Misc) else None
        except Exception:
            parent = None

        callback = self.on_login_success_callback or self.on_continue_guest

        # Fechar a janela atual para não deixar duas sobrepostas
        try:
            self._safe_destroy()
        except Exception:
            pass

        try:
            target_parent = parent or tk.Tk()
            try:
                target_parent.withdraw()
            except Exception:
                pass
            WelcomeWindow(target_parent, callback, start_mode=mode)
        except Exception as e:
            print(f"[LOG] Falha ao abrir WelcomeWindow: {e}")

    def _on_create_account(self):
        """Callback para criar conta."""
        self._open_full_welcome(mode="signup")

    def _on_upgrade_pro(self):
        """Callback para fazer upgrade PRO."""
        if self.on_upgrade_pro:
            self.on_upgrade_pro()
        try:
            self._safe_destroy()
        except Exception:
            pass

    def _on_guest_session_created(self, event):
        """Callback quando nova sessão Guest é criada com sucesso."""
        print("[LOG] Nova sessão Guest criada com sucesso")
        if self.on_continue_guest:
            self.on_continue_guest()
        try:
            self._safe_destroy()
        except Exception:
            pass

    def _on_guest_session_error(self, event):
        """Callback quando há erro na criação de sessão Guest."""
        error_msg = getattr(self, 'thread_error_msg', 'Erro desconhecido')
        self.lbl_status.configure(text=error_msg, foreground=self.colors["error"])
        messagebox.showerror(_("Erro"), error_msg, parent=self)

    # --- Login Functions ---

    def show_login_form(self):
        """Transfere para a WelcomeWindow em modo login."""
        self._open_full_welcome(mode="login")

    def hide_login_form(self):
        """Oculta o formulário de login e volta ao conteúdo principal."""
        self.login_form_frame.pack_forget()

        # Restaura conteúdo principal
        self._setup_header()
        self._setup_content()
        self.lbl_status.pack(pady=(15, 0))
        self.lbl_status.configure(text="")
        self.after(10, self._restore_window_position)

        # Rebindar eventos de teclado após restaurar conteúdo principal
        self._bind_field_events()

    def perform_login(self):
        """Valida e executa o login."""
        email = self.entry_login_email.get().strip()
        password = self.entry_login_password.get().strip()

        errors = []
        if not email:
            errors.append(_("Email necessário."))
        if not password:
            errors.append(_("Senha necessária."))

        if errors:
            msg = " • ".join(errors)
            self.lbl_status.configure(text=msg, foreground=self.colors["error"])
            messagebox.showerror(_("Erro de Validação"), msg, parent=self)
            return

        print("[DEBUG] GuestWelcomeWindow perform_login called", file=sys.stderr)
        self.set_loading(True, _("Autenticando..."))
        threading.Thread(target=self._login_thread, args=(email, password), daemon=True).start()

    def _login_thread(self, email, password):
        """Thread para executar o login em background."""
        try:
            print("[DEBUG] GuestWelcomeWindow calling login_user", file=sys.stderr)
            success, payload, err_type = config_manager.login_user(email, password, ui_language="pt-BR")
            print(f"[DEBUG] Guest login_user returned success={success}, err_type={err_type}", file=sys.stderr)
            if success:
                self.thread_result_data = payload
                self.queue.put("<<LoginSuccess>>")
            else:
                self.thread_error_msg = payload
                if err_type == "limit":
                    self.queue.put("<<LimitError>>")
                else:
                    self.queue.put("<<LoginError>>")
        except Exception as e:
            self.thread_error_msg = str(e)
            self.queue.put("<<LoginError>>")
        finally:
            self.queue.put("<<StopLoading>>")

    def _handle_login_response(self, response):
        """Processa a resposta do login."""
        if response.status_code == 429:
            self.thread_error_msg = _("Muitas tentativas. Aguarde.")
            self.queue.put("<<LoginError>>")
            return
        if response.status_code == 401:
            self.thread_error_msg = _("Credenciais inválidas.")
            self.queue.put("<<LoginError>>")
            return
        if response.status_code in (403, 500):
            try:
                msg = response.json().get("message", "Erro do servidor")
            except:
                msg = "Erro desconhecido"
            self.thread_error_msg = msg
            self.queue.put("<<LoginError>>")
            return

        response.raise_for_status()
        data = response.json()

        # Login bem-sucedido - processar dados da sessão
        self.thread_result_data = data
        self.queue.put("<<LoginSuccess>>")

    def _on_login_success(self, event):
        """Callback quando o login é bem-sucedido."""
        if self.thread_result_data:
            # Salva credenciais para login automático futuro
            email = self.entry_login_email.get().strip()
            password = self.entry_login_password.get().strip()
            if email and password:
                config_manager.save_user_credentials(email, password)

            # Processa resposta do bootstrap (similar ao welcome_window)
            self._process_bootstrap_response(self.thread_result_data, is_guest=False)
            self._call_login_success_callback()

    def _on_login_error(self, event):
        """Callback quando há erro no login."""
        error_msg = getattr(self, 'thread_error_msg', _("Erro no login"))
        self.lbl_status.configure(text=error_msg, foreground=self.colors["error"])

    def _process_bootstrap_response(self, data, is_guest):
        """Processa resposta do bootstrap e configura sessão (copiado do welcome_window)."""
        access_token = data.get("access_token")
        user = data.get("user", {})
        billing = data.get("billing", {})

        config_manager.set_session_data(
            access_token=access_token,
            user_id=user.get("id"),
            user_email=user.get("email"),
            user_name=user.get("name"),
            user_plan=user.get("plan"),
            user_language=user.get("language"),
            user_data=user,
            billing=billing,
            server_config={
                "transcription": data.get("transcription"),
                "work": data.get("work"),
                "image": data.get("image")
            },
            limits=data.get("limits", {}),
            is_guest=is_guest
        )

        self._save_window_position()
        self.destroy()

    def _call_login_success_callback(self):
        print("DEBUG: GuestWelcomeWindow login success callback", file=sys.stderr)
        if self.on_login_success_callback:
            self.on_login_success_callback()

        # Chama callback de sucesso (similar ao on_success_callback do welcome_window)
        if hasattr(self, 'on_success_callback') and self.on_success_callback:
            self.on_success_callback()

    def update_language(self):
        """Atualiza textos quando idioma muda."""
        self.title(_("VoxFluens"))
        # Reconfigurar todos os textos...
        pass

    def on_close(self):
        """Callback quando a janela é fechada."""
        # Fecha a janela e encerra totalmente o aplicativo (comportamento esperado ao fechar a janela de boas-vindas)
        try:
            self._safe_destroy()
        except Exception:
            pass
        # Tenta fechar o root (pai) se houver
        try:
            # Prefer to destroy the explicit parent passed at creation (self._passed_parent),
            # if available. Otherwise, try the tkinter default root.
            candidate = getattr(self, '_passed_parent', None) or getattr(tk, '_default_root', None)
            if candidate:
                try:
                    candidate.destroy()
                except Exception:
                    pass
        except Exception:
            pass
        # Finaliza o processo Python
        try:
            import sys
            sys.exit(0)
        except SystemExit:
            # Transmitir para fora do handler
            raise

    def _safe_destroy(self):
        """Destroy the Toplevel safely without raising exceptions if Tk has been torn down."""
        try:
            self.destroy()
        except tk.TclError:
            pass


if __name__ == "__main__":
    # Teste da janela
    root = tk.Tk()
    root.withdraw()

    def on_continue():
        print("Continuando como guest")

    def on_create():
        print("Criando conta")

    def on_upgrade():
        print("Fazendo upgrade")

    try:
        guest_window = GuestWelcomeWindow(root, on_continue, on_create, on_upgrade)
        root.wait_window(guest_window)
    except Exception as e:
        print(f"Erro: {e}")
        import traceback
        traceback.print_exc()

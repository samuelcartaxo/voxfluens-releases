"""
🌍 UI para Gerenciamento de País de Cobrança

Permite usuários mudar seu país de cobrança (billing_country)
Integrado com BillingCountryService

Uso:
    from ui.billing_country_selector import BillingCountryDialog
    dialog = BillingCountryDialog(parent, billing_service=service)
    dialog.show()
"""

import logging
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Callable
from dataclasses import dataclass

from payments.billing_country_service import BillingCountryService, SUPPORTED_COUNTRIES

logger = logging.getLogger("billing_country_selector")


@dataclass
class BillingCountrySelectorConfig:
    """Configuração do seletor de país de cobrança."""
    
    width: int = 400
    height: int = 300
    title: str = "Alterar País de Cobrança"
    resizable: bool = False
    modal: bool = True


class BillingCountryDialog(tk.Toplevel):
    """
    Diálogo para seleção/mudança de país de cobrança.
    
    Funcionalidades:
    - Lista países suportados
    - Mostra moeda e preço por país
    - Valida mudança de país
    - Integrado com BillingCountryService
    - Feedback visual (sucesso/erro)
    
    Segurança:
    - Apenas backend pode alterar billing_country
    - Rejeita país inválido
    - Valida transação pelo backend
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        billing_service: Optional[BillingCountryService] = None,
        on_country_changed: Optional[Callable[[str], None]] = None,
        config: Optional[BillingCountrySelectorConfig] = None
    ):
        """
        Inicializar diálogo de seleção de país.
        
        Args:
            parent: Widget pai (janela principal)
            billing_service: Serviço de cobrança (obrigatório)
            on_country_changed: Callback quando país é mudado
            config: Configuração do diálogo
        """
        super().__init__(parent)
        
        self.billing_service = billing_service
        self.on_country_changed = on_country_changed
        self.config = config or BillingCountrySelectorConfig()
        self.selected_country = None
        
        # Validação
        if not billing_service:
            logger.warning("BillingCountryService não fornecido")
        
        # Configurar diálogo
        self.title(self.config.title)
        self.geometry(f"{self.config.width}x{self.config.height}")
        self.resizable(self.config.resizable, self.config.resizable)
        
        if self.config.modal:
            self.transient(parent)
            self.grab_set()
        
        # Construir UI
        self._build_ui()
        
        # Centralizar na janela pai
        self._center_on_parent(parent)
        
        logger.info("BillingCountryDialog inicializado")
    
    def _build_ui(self):
        """Construir interface do usuário."""
        # Frame principal
        main_frame = ttk.Frame(self, padding="15")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Título
        title_label = ttk.Label(
            main_frame,
            text="🌍 Selecione seu País de Cobrança",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Descrição
        desc_label = ttk.Label(
            main_frame,
            text="Seu país determina a moeda de cobrança e o preço",
            font=("TkDefaultFont", 9),
            foreground="#666666"
        )
        desc_label.pack(pady=(0, 15))
        
        # Frame para lista de países
        self.listbox_frame = ttk.Frame(main_frame)
        self.listbox_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(self.listbox_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Listbox com países
        self.listbox = tk.Listbox(
            self.listbox_frame,
            yscrollcommand=scrollbar.set,
            height=8,
            width=45,
            font=("TkDefaultFont", 9)
        )
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)
        
        # Popula listbox
        self._populate_countries()
        
        # Bind para seleção
        self.listbox.bind('<<ListboxSelect>>', self._on_country_select)
        
        # Info selecionado
        self.info_label = ttk.Label(
            main_frame,
            text="Selecione um país para ver detalhes",
            font=("TkDefaultFont", 9),
            foreground="#0066CC"
        )
        self.info_label.pack(pady=5)
        
        # Frame de botões
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        # Botão Confirmar
        self.confirm_btn = ttk.Button(
            button_frame,
            text="✓ Confirmar Mudança",
            command=self._on_confirm_clicked
        )
        self.confirm_btn.pack(side=tk.LEFT, padx=(0, 5))
        self.confirm_btn.config(state=tk.DISABLED)
        
        # Botão Cancelar
        cancel_btn = ttk.Button(
            button_frame,
            text="✗ Cancelar",
            command=self.destroy
        )
        cancel_btn.pack(side=tk.LEFT)
    
    def _populate_countries(self):
        """Popula a listbox com países suportados."""
        self.listbox.delete(0, tk.END)
        
        for country_code, country_info in SUPPORTED_COUNTRIES.items():
            # Formato: 🇧🇷 Brasil (R$) | R$ 29,00/mês
            display_text = (
                f"🌍 {country_info.name} ({country_info.currency_symbol}) | "
                f"{country_info.monthly_price}/mês"
            )
            self.listbox.insert(tk.END, display_text)
        
        logger.info(f"Listbox populada com {len(SUPPORTED_COUNTRIES)} países")
    
    def _on_country_select(self, event):
        """Handler para seleção de país."""
        selection = self.listbox.curselection()
        if not selection:
            return
        
        idx = selection[0]
        country_codes = list(SUPPORTED_COUNTRIES.keys())
        self.selected_country = country_codes[idx]
        
        country_info = SUPPORTED_COUNTRIES[self.selected_country]
        
        # Atualizar info
        info_text = (
            f"✓ Selecionado: {country_info.name} ({self.selected_country})\n"
            f"  Moeda: {country_info.currency.upper()}\n"
            f"  Mensal: {country_info.monthly_price}\n"
            f"  Anual: {country_info.annual_price}"
        )
        self.info_label.config(text=info_text, foreground="#008000")
        
        # Habilitar botão confirmar
        self.confirm_btn.config(state=tk.NORMAL)
        
        logger.info(f"País selecionado: {self.selected_country}")
    
    def _on_confirm_clicked(self):
        """Handler para confirmação de mudança."""
        if not self.selected_country:
            messagebox.showwarning("Aviso", "Selecione um país para continuar")
            return
        
        if not self.billing_service:
            messagebox.showerror(
                "Erro",
                "Serviço de cobrança não disponível"
            )
            logger.error("BillingCountryService não disponível")
            return
        
        # Desabilitar botão durante processamento
        self.confirm_btn.config(state=tk.DISABLED)
        self.update()
        
        try:
            # Chamar serviço para atualizar país
            logger.info(f"Atualizando country para: {self.selected_country}")
            result = self.billing_service.update_billing_country(
                self.selected_country
            )
            
            # Sucesso
            country_name = SUPPORTED_COUNTRIES[self.selected_country].name
            messagebox.showinfo(
                "Sucesso",
                f"País de cobrança atualizado para {country_name}"
            )
            
            logger.info(f"País atualizado com sucesso: {result}")
            
            # Callback
            if self.on_country_changed:
                self.on_country_changed(self.selected_country)
            
            self.destroy()
        
        except ValueError as e:
            messagebox.showerror("Erro de Validação", str(e))
            logger.error(f"Erro de validação: {e}")
            self.confirm_btn.config(state=tk.NORMAL)
        
        except Exception as e:
            messagebox.showerror(
                "Erro",
                f"Erro ao atualizar país: {str(e)}"
            )
            logger.error(f"Erro ao atualizar país: {e}")
            self.confirm_btn.config(state=tk.NORMAL)
    
    def _center_on_parent(self, parent: tk.Widget):
        """Centralizar diálogo na janela pai."""
        self.update_idletasks()
        
        parent_x = parent.winfo_x()
        parent_y = parent.winfo_y()
        parent_width = parent.winfo_width()
        parent_height = parent.winfo_height()
        
        dialog_width = self.winfo_width()
        dialog_height = self.winfo_height()
        
        x = parent_x + (parent_width - dialog_width) // 2
        y = parent_y + (parent_height - dialog_height) // 2
        
        self.geometry(f"+{x}+{y}")


class BillingCountrySelector(ttk.Frame):
    """
    Frame compacto para seleção de país de cobrança.
    
    Uso em settings/dashboard:
        selector = BillingCountrySelector(
            parent,
            billing_service=service,
            on_country_changed=callback
        )
        selector.pack()
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        billing_service: Optional[BillingCountryService] = None,
        on_country_changed: Optional[Callable[[str], None]] = None
    ):
        """Inicializar seletor compacto."""
        super().__init__(parent)
        
        self.billing_service = billing_service
        self.on_country_changed = on_country_changed
        
        # Construir UI compacta
        self._build_ui()
    
    def _build_ui(self):
        """Construir UI compacta."""
        # Label
        label = ttk.Label(
            self,
            text="🌍 País de Cobrança:",
            font=("TkDefaultFont", 10)
        )
        label.pack(side=tk.LEFT, padx=(0, 10))
        
        # Combobox
        self.country_var = tk.StringVar()
        
        # Opções
        country_options = [
            f"{info.name} ({info.currency.upper()})"
            for info in SUPPORTED_COUNTRIES.values()
        ]
        
        self.combo = ttk.Combobox(
            self,
            textvariable=self.country_var,
            values=country_options,
            state="readonly",
            width=25
        )
        self.combo.pack(side=tk.LEFT, padx=(0, 10))
        
        # Preço
        self.price_label = ttk.Label(
            self,
            text="",
            font=("TkDefaultFont", 10),
            foreground="#008000"
        )
        self.price_label.pack(side=tk.LEFT, padx=(0, 10))
        
        # Botão de mudança
        change_btn = ttk.Button(
            self,
            text="Alterar",
            command=self._on_change_clicked
        )
        change_btn.pack(side=tk.LEFT)
        
        # Bind para atualizar preço
        self.combo.bind('<<ComboboxSelected>>', self._on_selection_changed)
        
        logger.info("BillingCountrySelector construído")
    
    def _on_selection_changed(self, event):
        """Atualizar preço quando seleção muda."""
        selection = self.combo.current()
        if selection >= 0:
            country_codes = list(SUPPORTED_COUNTRIES.keys())
            country_code = country_codes[selection]
            country_info = SUPPORTED_COUNTRIES[country_code]
            
            self.price_label.config(
                text=f"R$ 29,00/mês" if country_code == 'BR' else "$9.99/mês"
            )
    
    def _on_change_clicked(self):
        """Abrir diálogo de mudança."""
        selection = self.combo.current()
        if selection < 0:
            messagebox.showwarning("Aviso", "Selecione um país primeiro")
            return
        
        # Abrir diálogo modal
        dialog = BillingCountryDialog(
            self.winfo_toplevel(),
            billing_service=self.billing_service,
            on_country_changed=self.on_country_changed
        )
        dialog.focus_set()


if __name__ == '__main__':
    # Demo
    root = tk.Tk()
    root.title("Demo: Billing Country Selector")
    root.geometry("500x400")
    
    # Criar serviço mock
    service = BillingCountryService(
        api_base_url="https://api.test.com",
        access_token="test_token"
    )
    
    def on_changed(country):
        print(f"✅ País mudado para: {country}")
    
    # Criar seletor
    selector = BillingCountrySelector(
        root,
        billing_service=service,
        on_country_changed=on_changed
    )
    selector.pack(pady=20, padx=20, fill=tk.X)
    
    # Botão de teste
    def open_dialog():
        dialog = BillingCountryDialog(
            root,
            billing_service=service,
            on_country_changed=on_changed
        )
        dialog.focus_set()
    
    test_btn = ttk.Button(
        root,
        text="Abrir Diálogo",
        command=open_dialog
    )
    test_btn.pack(pady=10)
    
    root.mainloop()

import tkinter as tk
from tkinter import ttk, messagebox
import requests
import threading
import i18n
from PIL import Image, ImageTk
import os
import sys
import config_manager
import queue

_ = i18n._


def _call_toplevel_method(instance, method_name, *args, **kwargs):
    method = getattr(super(type(instance), instance), method_name, None)
    if callable(method):
        return method(*args, **kwargs)

class WelcomeWindow(tk.Toplevel):
    def __init__(self, parent, on_success_callback, start_mode=None):
        """Inicializa a janela de boas-vindas com design moderno, persistência e sem flicker."""
        super().__init__(parent)
        self.parent = parent
        self.on_success_callback = on_success_callback
        self.start_mode = (start_mode or "").lower()
        
        # 1. OCULTAR IMEDIATAMENTE: Evita que a janela apareça "pelada" ou no lugar errado (flicker)
        self.withdraw()
        
        # Configurações básicas
        self.title(_("VoxFluens"))
        
        # Fundo com gradiente sutil
        self.configure(bg="#FFFFFF")
        
        # Remover bordas da janela para aparência mais moderna
        self.overrideredirect(False)  # Manter bordas do sistema para melhor usabilidade
        
        self.resizable(False, False)
        
        # Estado interno
        self.logo_clicks = 0
        self.thread_result_data = None
        self.thread_error_msg = None
        self.queue = queue.Queue()

        # Estilização e UI
        self._configure_styles()
        self.setup_ui()
        
        # 2. AGENDAR EXIBIÇÃO:
        # Usamos after(0) para permitir que o ciclo de eventos processe a criação dos widgets
        # antes de calculamos a geometria e mostrarmos a janela.
        self.after(0, self._initial_show)
        # Aplicar modo inicial (login/signup) logo após a janela estabilizar
        if self.start_mode in ("login", "signup", "register", "create"):
            self.after(50, self._apply_start_mode)

        # Bindings
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._bind_events()
        
        # Inicia processamento da fila
        self.process_queue()

    def geometry(self, *args, **kwargs):
        return _call_toplevel_method(self, "geometry", *args, **kwargs)

    def resizable(self, *args, **kwargs):
        return _call_toplevel_method(self, "resizable", *args, **kwargs)

    def configure(self, *args, **kwargs):
        return _call_toplevel_method(self, "configure", *args, **kwargs)

    def title(self, *args, **kwargs):
        return _call_toplevel_method(self, "title", *args, **kwargs)

    def protocol(self, *args, **kwargs):
        return _call_toplevel_method(self, "protocol", *args, **kwargs)

    def lift(self, *args, **kwargs):
        return _call_toplevel_method(self, "lift", *args, **kwargs)

    def focus_force(self, *args, **kwargs):
        return _call_toplevel_method(self, "focus_force", *args, **kwargs)

    def overrideredirect(self, *args, **kwargs):
        return _call_toplevel_method(self, "overrideredirect", *args, **kwargs)

    def _initial_show(self):
        """Método chamado uma única vez para exibir a janela inicial."""
        self._restore_window_position()
        
        # 3. REVELAR E ATIVAR: Só agora mostramos a janela
        self.deiconify() 
        self.lift()
        self.focus_force()
        
        # Configurar modalidade (grab) apenas após a janela estar visível
        try:
            self.grab_set()
        except Exception:
            pass # Pode falhar em casos raros de timing, mas não é crítico

    def _configure_styles(self):
        """Configura estilos ttk modernos."""
        style = ttk.Style(self)
        style.theme_use("clam")
        
        self.colors = {
            "bg": "#FFFFFF",
            "card_bg": "#FFFFFF",  # right column (forms) remains white
            "left_card_bg": "#F1F6FF",  # restore light blue for left info card
            "entry_bg": "#FFFFFF",
            "entry_border": "#D7E3FF",
            "primary": "#2563EB",
            "primary_hover": "#1D4ED8",
            "text_main": "#1E293B",
            "text_light": "#64748B",
            "error": "#EF4444",
            "success": "#10B981",
            "border": "#E2E8F0"
        }

        style.configure(".", background=self.colors["bg"], font=("Segoe UI", 10))
        style.configure("TFrame", background=self.colors["bg"])
        style.configure("Card.TFrame", background=self.colors["card_bg"], relief="solid", borderwidth=1, bordercolor=self.colors["border"])
        style.configure("Header.TLabel", font=("Segoe UI", 18, "bold"), foreground=self.colors["primary"])
        style.configure("Subheader.TLabel", font=("Segoe UI", 11), foreground=self.colors["text_light"])
        style.configure("Body.TLabel", font=("Segoe UI", 10), foreground=self.colors["text_main"])
        style.configure("Link.TLabel", font=("Segoe UI", 10, "underline"), foreground=self.colors["primary"])
        style.configure("Error.TLabel", font=("Segoe UI", 9), foreground=self.colors["error"])

        # Labels used inside Card.TFrame should match the card background
        style.configure("CardHeader.TLabel", background=self.colors["card_bg"], font=("Segoe UI", 11, "bold"), foreground=self.colors["primary"])
        style.configure("CardBody.TLabel", background=self.colors["card_bg"], font=("Segoe UI", 9), foreground=self.colors["text_main"])
        style.configure("CardLink.TLabel", background=self.colors["card_bg"], font=("Segoe UI", 9, "underline"), foreground=self.colors["primary"])
        style.configure("CardSubheader.TLabel", background=self.colors["card_bg"], font=("Segoe UI", 11), foreground=self.colors["text_light"])

        # Left info card styles
        style.configure("LeftCard.TFrame", background=self.colors["left_card_bg"], relief="solid", borderwidth=1, bordercolor=self.colors["border"])
        style.configure("LeftCardHeader.TLabel", background=self.colors["left_card_bg"], font=("Segoe UI", 11, "bold"), foreground=self.colors["primary"])
        style.configure("LeftCardBody.TLabel", background=self.colors["left_card_bg"], font=("Segoe UI", 9), foreground=self.colors["text_main"])
        style.configure("LeftCardLink.TLabel", background=self.colors["left_card_bg"], font=("Segoe UI", 9, "underline"), foreground=self.colors["primary"])

        style.configure("Accent.TButton",
            font=("Segoe UI", 10, "bold"),
            foreground="#FFFFFF",
            background=self.colors["primary"],
            borderwidth=0,
            padding=(20, 10)
        )
        style.map("Accent.TButton",
            background=[("active", self.colors["primary_hover"]), ("disabled", self.colors["text_light"])],
            foreground=[("disabled", "#F1F5F9")]
        )

        # Estilo para botão secundário (login)
        style.configure("Secondary.TButton",
            font=("Segoe UI", 10),
            foreground=self.colors["primary"],
            background="#FFFFFF",
            borderwidth=1,
            relief="solid",
            bordercolor=self.colors["primary"],
            padding=(20, 8)
        )
        style.map("Secondary.TButton",
            background=[("active", "#F8FAFC")],
            bordercolor=[("active", self.colors["primary_hover"])]
        )

        # Estilo para botão outline (signup)
        style.configure("Outline.TButton",
            font=("Segoe UI", 10),
            foreground=self.colors["primary"],
            background="#FFFFFF",
            borderwidth=2,
            relief="solid",
            bordercolor=self.colors["primary"],
            padding=(20, 8)
        )
        style.map("Outline.TButton",
            background=[("active", self.colors["primary"]), ("pressed", self.colors["primary"])],
            foreground=[("active", "#FFFFFF"), ("pressed", "#FFFFFF")],
            bordercolor=[("active", self.colors["primary"])]
        )

        style.configure("Soft.TEntry",
            fieldbackground=self.colors["entry_bg"],
            background=self.colors["entry_bg"],
            borderwidth=1,
            relief="solid",
            padding=(8, 6),
            bordercolor=self.colors["entry_border"]
        )
        
        style.configure("Focus.Soft.TEntry",
            fieldbackground=self.colors["entry_bg"],
            background=self.colors["entry_bg"],
            borderwidth=2,
            relief="solid",
            padding=(8, 6),
            bordercolor=self.colors["primary"]
        )
        
    def setup_ui(self):
        self.main_container = ttk.Frame(self, padding=(24, 20))
        self.main_container.pack(fill="both", expand=True)

        self.columns_frame = ttk.Frame(self.main_container)
        self.columns_frame.pack(fill="both", expand=True)
        self.columns_frame.columnconfigure(0, weight=1)
        self.columns_frame.columnconfigure(1, weight=1)

        self._setup_left_column()
        self._setup_right_column()

        self.lbl_status = tk.Text(
            self.main_container,
            height=3,
            wrap="word",
            state="disabled",
            bg=self.colors["bg"],
            fg=self.colors["error"],
            font=("Segoe UI", 9),
            borderwidth=0,
            highlightthickness=0,
        )
        self.lbl_status.pack(fill="x", pady=(12, 0))

    def _setup_left_column(self):
        self.left_column = ttk.Frame(self.columns_frame)
        self.left_column.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self._setup_header(self.left_column)
        self._setup_upgrade_card(self.left_column)

    def _setup_header(self, parent):
        header_frame = ttk.Frame(parent)
        header_frame.pack(fill="x", pady=(0, 12))

        try:
            if hasattr(sys, '_MEIPASS'):
                logo_path = os.path.join(sys._MEIPASS, "voxfluens_icon64x64.ico")
            else:
                logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "voxfluens_icon64x64.ico")
                if not os.path.exists(logo_path):
                    logo_path = "voxfluens_icon64x64.ico"
            
            if os.path.exists(logo_path):
                pil_image = Image.open(logo_path)
                pil_image = pil_image.resize((64, 64), Image.Resampling.LANCZOS)
                self.logo_img = ImageTk.PhotoImage(pil_image)
                logo_label = tk.Label(header_frame, image=self.logo_img, bg=self.colors["bg"], cursor="hand2")
                logo_label.pack(pady=(0, 15))
                logo_label.bind("<Button-1>", self.on_logo_click)
        except Exception as e:
            print(f"Logo load error: {e}")
            ttk.Label(header_frame, text="VoxFluens", style="Header.TLabel").pack(pady=(0, 15))

        ttk.Label(
            header_frame,
            text=_("Sua voz, transformada em texto e ação."),
            style="Header.TLabel",
            justify="center",
            anchor="center",
            wraplength=360,
        ).pack(fill="x", pady=(0, 6))
        ttk.Label(
            header_frame,
            text=_("Aumente sua produtividade com transcrição em tempo real e comandos de voz."),
            style="Subheader.TLabel",
            justify="center",
            anchor="center",
            wraplength=360,
        ).pack(fill="x")

        # Dica de conversao PRO
        pro_hint_frame = ttk.Frame(header_frame)
        pro_hint_frame.pack(fill="x", pady=(10, 0))

        pro_text_label = ttk.Label(
            pro_hint_frame,
            text=_("Experimente limites ilimitados no plano PRO"),
            style="Subheader.TLabel",
            justify="left",
            anchor="w",
            wraplength=340,
        )
        pro_text_label.pack(side="left", fill="x", expand=True, padx=(0, 8))

        pro_link_label = ttk.Label(
            pro_hint_frame,
            text=_("Saiba mais "),
            style="Link.TLabel",
        )
        pro_link_label.pack(side="right")
        pro_link_label.bind("<Button-1>", self.on_pro_link_click)
        pro_link_label.configure(cursor="hand2")

    def _setup_upgrade_card(self, parent):
        self.pro_benefits_frame = ttk.Frame(parent, style="LeftCard.TFrame")
        self.pro_benefits_frame.pack(fill="x", pady=(10, 0))

        pro_title_label = ttk.Label(
            self.pro_benefits_frame,
            text=_(" Desbloqueie o Potencial Completo"),
            style="LeftCardHeader.TLabel",
        )
        pro_title_label.pack(anchor="w", pady=(10, 4), padx=12)

        benefits_text = _("- Transcrições ilimitadas\n- Suporte prioritário\n- Sem anúncios")

        pro_benefits_label = ttk.Label(
            self.pro_benefits_frame,
            text=benefits_text,
            style="LeftCardBody.TLabel",
            justify="left",
            anchor="w",
        )
        pro_benefits_label.pack(anchor="w", padx=12, pady=(0, 8))

        upgrade_btn = ttk.Label(
            self.pro_benefits_frame,
            text=_("Fazer upgrade para PRO "),
            style="LeftCardLink.TLabel",
        )
        upgrade_btn.pack(anchor="e", padx=12, pady=(0, 10))
        upgrade_btn.bind("<Button-1>", self.on_pro_link_click)
        upgrade_btn.configure(cursor="hand2")

    def _setup_right_column(self):
        self.right_column = ttk.Frame(self.columns_frame, style="Card.TFrame")
        self.right_column.grid(row=0, column=1, sticky="nsew", padx=(12, 0))
        self.content_frame = ttk.Frame(self.right_column, padding=(18, 16), style="Card.TFrame")
        self.content_frame.pack(fill="both", expand=True)
        self._setup_content()

    def _setup_content(self):
        self.card_title_label = ttk.Label(self.content_frame, text="", style="CardHeader.TLabel", justify="center")
        self.card_title_label.pack(fill="x", pady=(0, 10))

        self.btn_guest = ttk.Button(
            self.content_frame,
            text=_(" Experimentar Agora"),
            command=self.start_guest_mode,
            style="Accent.TButton",
            cursor="hand2",
        )
        self.btn_guest.pack(fill="x", pady=(0, 8))

        # Pitch dinâmico conforme modo (guest/signup/login)
        self.pitch_label = ttk.Label(
            self.content_frame,
            text=_("guest_trial_pitch"),
            style="CardSubheader.TLabel",
            wraplength=320,
            justify="center",
        )
        self.pitch_label.pack(pady=(0, 12))

        self.login_trigger_frame = ttk.Frame(self.content_frame)
        self.login_trigger_frame.pack(fill="x", pady=(8, 4))

        actions_frame = ttk.Frame(self.login_trigger_frame)
        actions_frame.pack(fill="x", pady=(0, 8))

        self.btn_show_signup = ttk.Button(
            actions_frame,
            text=_("Criar conta gratuita"),
            command=self.show_signup_fields,
            style="Outline.TButton",
            cursor="hand2",
        )
        self.btn_show_signup.pack(fill="x", pady=(0, 8))

        self.btn_show_login = ttk.Button(
            actions_frame,
            text=_("Já tenho conta - Fazer Login"),
            command=self.show_login_fields,
            style="Secondary.TButton",
            cursor="hand2",
        )
        self.btn_show_login.pack(fill="x")

        self.login_form_frame = ttk.Frame(self.content_frame)

        ttk.Label(self.login_form_frame, text=_("Email"), style="CardBody.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_login_email = ttk.Entry(self.login_form_frame, font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_login_email.pack(fill="x", pady=(0, 8))
        self._bind_focus_highlight(self.entry_login_email)

        ttk.Label(self.login_form_frame, text=_("Senha"), style="CardBody.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_login_password = ttk.Entry(self.login_form_frame, show="*", font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_login_password.pack(fill="x", pady=(0, 12))
        self._bind_focus_highlight(self.entry_login_password)

        self.btn_login = ttk.Button(
            self.login_form_frame, text=_("Entrar"), command=self.perform_login, style="Accent.TButton", cursor="hand2"
        )
        self.btn_login.pack(fill="x", pady=(4, 10))

        self.lbl_forgot_password = ttk.Label(self.login_form_frame, text=_("forgot_password"), style="CardLink.TLabel")
        self.lbl_forgot_password.pack(pady=(0, 4))
        self.lbl_forgot_password.bind("<Button-1>", self._show_password_reset)
        self.lbl_forgot_password.configure(cursor="hand2")

        self.lbl_login_back = ttk.Label(self.login_form_frame, text=_("Voltar"), style="CardBody.TLabel")
        self.lbl_login_back.pack()
        self.lbl_login_back.bind("<Button-1>", lambda e: self.hide_auth_fields())
        self.lbl_login_back.configure(cursor="hand2")

        self.signup_form_frame = ttk.Frame(self.content_frame)

        ttk.Label(self.signup_form_frame, text=_("Nome"), style="CardBody.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_signup_name = ttk.Entry(self.signup_form_frame, font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_signup_name.pack(fill="x", pady=(0, 8))
        self._bind_focus_highlight(self.entry_signup_name)

        ttk.Label(self.signup_form_frame, text=_("Email"), style="CardBody.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_signup_email = ttk.Entry(self.signup_form_frame, font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_signup_email.pack(fill="x", pady=(0, 8))
        self._bind_focus_highlight(self.entry_signup_email)

        ttk.Label(self.signup_form_frame, text=_("Senha (mínimo 8 caracteres)"), style="CardBody.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_signup_password = ttk.Entry(self.signup_form_frame, show="*", font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_signup_password.pack(fill="x", pady=(0, 8))
        self._bind_focus_highlight(self.entry_signup_password)

        ttk.Label(self.signup_form_frame, text=_("Confirmar Senha"), style="CardBody.TLabel").pack(anchor="w", pady=(0, 2))
        self.entry_signup_confirm = ttk.Entry(self.signup_form_frame, show="*", font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_signup_confirm.pack(fill="x", pady=(0, 12))
        self._bind_focus_highlight(self.entry_signup_confirm)

        self.btn_signup = ttk.Button(
            self.signup_form_frame,
            text=_("Criar Conta"),
            command=self.perform_signup,
            style="Accent.TButton",
            cursor="hand2",
        )
        self.btn_signup.pack(fill="x", pady=(4, 10))

        self.lbl_signup_back = ttk.Label(self.signup_form_frame, text=_("Voltar"), style="CardBody.TLabel")
        self.lbl_signup_back.pack()
        self.lbl_signup_back.bind("<Button-1>", lambda e: self.hide_auth_fields())
        self.lbl_signup_back.configure(cursor="hand2")

        self.success_frame = ttk.Frame(self.content_frame)

        success_label = ttk.Label(self.success_frame, text=_("Conta criada com sucesso!"), style="CardHeader.TLabel")
        success_label.pack(pady=(16, 8))

        info_label = ttk.Label(
            self.success_frame,
            text=_("Verifique seu email para confirmar a conta e depois faça login."),
            style="CardBody.TLabel",
            justify="center",
            wraplength=320,
        )
        info_label.pack(pady=(0, 12))

        token_label = ttk.Label(self.success_frame, text=_("Cole seu código de verificação aqui"), style="CardBody.TLabel")
        token_label.pack(pady=(0, 4))

        self.entry_verify_token = ttk.Entry(self.success_frame, font=("Segoe UI", 11), style="Soft.TEntry")
        self.entry_verify_token.pack(fill="x", pady=(0, 8))
        self._bind_focus_highlight(self.entry_verify_token)

        self.btn_verify = ttk.Button(
            self.success_frame, text=_("Verificar Conta"), command=self.perform_verify, style="Accent.TButton", cursor="hand2"
        )
        self.btn_verify.pack(pady=(0, 8))

        self.btn_go_to_login = ttk.Button(
            self.success_frame,
            text=_("Fazer Login"),
            command=self.show_login_fields,
            style="Accent.TButton",
            cursor="hand2",
        )
        self.btn_go_to_login.pack(pady=(0, 8))

    def _set_status_text(self, text, color):
        """Helper to set text in the status Text widget."""
        self.lbl_status.config(state="normal")
        self.lbl_status.delete(1.0, tk.END)
        self.lbl_status.insert(1.0, text)
        self.lbl_status.config(fg=color, state="disabled")

    def _bind_focus_highlight(self, entry_widget):
        def on_focus_in(e):
            # Remove o background customizado para evitar conflitos visuais
            e.widget.configure(style="Focus.Soft.TEntry")
        def on_focus_out(e):
            e.widget.configure(style="Soft.TEntry")
        entry_widget.bind("<FocusIn>", on_focus_in)
        entry_widget.bind("<FocusOut>", on_focus_out)

    def _restore_window_position(self):
        """Calcula dimensões e restaura posição."""
        self.update_idletasks() # Força cálculo de tamanho dos widgets
        
        req_width = self.main_container.winfo_reqwidth()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        target_width = max(840, min(960, req_width + 40))
        req_height = self.main_container.winfo_reqheight()
        target_height = min(max(req_height + 10, 520), int(screen_height * 0.85))

        x = max(0, (screen_width - target_width) // 2)
        y = max(0, (screen_height - target_height) // 2)
        
        # Aplica a geometria (ainda invisível se chamado no início)
        self.geometry(f"{target_width}x{target_height}+{x}+{y}")

    def _save_window_position(self):
        # Persistência desativada para evitar comportamento indevido de posição
        return

    def show_login_fields(self, event=None):
        self._hide_all_forms()
        self.card_title_label.config(text=_("Fazer Login"))
        self.login_form_frame.pack(fill="x", expand=True)
        self.entry_login_email.focus_set()
        if hasattr(self, "pitch_label"):
            self.pitch_label.config(text=_("login_pitch"))

        self.after(10, self._restore_window_position)
        # Reconfigurar bindings de teclado para o formulário de login
        self.after(100, self._bind_field_events)

    def show_signup_fields(self, event=None):
        self._hide_all_forms()
        self.card_title_label.config(text=_("Criar Conta"))
        self.signup_form_frame.pack(fill="x", expand=True)
        self.entry_signup_name.focus_set()
        if hasattr(self, "pitch_label"):
            self.pitch_label.config(text=_("signup_pitch"))
        self.after(10, self._restore_window_position)
        # Reconfigurar bindings de teclado para o formulário de signup
        self.after(100, self._bind_field_events)

    def hide_auth_fields(self):
        self._hide_all_forms()
        self.card_title_label.config(text="")
        self.btn_guest.pack(fill="x", pady=(0, 8))
        self.login_trigger_frame.pack(fill="x", pady=(8, 4))
        self._set_status_text("", self.colors["text_main"])
        if hasattr(self, "pitch_label"):
            self.pitch_label.config(text=_("guest_trial_pitch"))
        self.after(10, self._restore_window_position)

    def _hide_all_forms(self):
        self.btn_guest.pack_forget()
        self.login_trigger_frame.pack_forget()
        self.login_form_frame.pack_forget()
        self.signup_form_frame.pack_forget()
        self.success_frame.pack_forget()

    def _apply_start_mode(self):
        """Aplica a visualização inicial (login ou signup) conforme solicitado pelo chamador."""
        if self.start_mode == "login":
            self.show_login_fields()
        elif self.start_mode in ("signup", "register", "create"):
            self.show_signup_fields()
        else:
            self.hide_auth_fields()

    # --- Logic & Events ---

    def _bind_events(self):
        self.bind("<<GuestLoginSuccess>>", self.on_guest_login_success_event)
        self.bind("<<LoginSuccess>>", self.on_login_success_event)
        self.bind("<<SignupSuccess>>", self.on_signup_success_event)
        self.bind("<<VerifySuccess>>", self.on_verify_success_event)
        self.bind("<<VerifyError>>", self.on_verify_error_event)
        self.bind("<<LoginError>>", self.on_login_error_event)
        self.bind("<<SignupError>>", self.on_signup_error_event)
        self.bind("<<LimitError>>", self.on_limit_error_event)
        self.bind("<<StopLoading>>", self.on_stop_loading_event)

        # Adicionar navegação por teclado sem afetar o visual
        self._setup_keyboard_navigation()

    def _setup_keyboard_navigation(self):
        """Configura navegação por teclado mantendo o design visual intacto."""
        # Bindings globais para navegação por teclado
        self.bind('<Return>', self._handle_enter_key)
        self.bind('<KP_Enter>', self._handle_enter_key)  # NumPad Enter
        self.bind('<Escape>', self._handle_escape_key)

        # Bindings específicos nos campos quando eles existem
        self._bind_field_events()

    def _bind_field_events(self):
        """Configura eventos específicos nos campos de entrada."""
        # Bindings para campos de login
        if hasattr(self, 'entry_login_email'):
            self.entry_login_email.bind('<Return>', lambda e: self._handle_field_enter('email'))
        if hasattr(self, 'entry_login_password'):
            self.entry_login_password.bind('<Return>', lambda e: self._handle_field_enter('password'))

        # Bindings para campos de signup
        if hasattr(self, 'entry_signup_name'):
            self.entry_signup_name.bind('<Return>', lambda e: self._handle_field_enter('signup_name'))
        if hasattr(self, 'entry_signup_email'):
            self.entry_signup_email.bind('<Return>', lambda e: self._handle_field_enter('signup_email'))
        if hasattr(self, 'entry_signup_password'):
            self.entry_signup_password.bind('<Return>', lambda e: self._handle_field_enter('signup_password'))
        if hasattr(self, 'entry_signup_confirm'):
            self.entry_signup_confirm.bind('<Return>', lambda e: self._handle_field_enter('signup_confirm'))

    def _handle_enter_key(self, event):
        """Gerencia tecla Enter baseada no widget ativo."""
        current = self.focus_get()

        # Se estamos em um campo de entrada, delegar para o handler específico
        if hasattr(current, 'get'):  # É um Entry widget
            if current == getattr(self, 'entry_login_password', None):
                self._handle_field_enter('password')()
            elif current == getattr(self, 'entry_signup_confirm', None):
                self._handle_field_enter('signup_confirm')()
            else:
                # Para outros campos, mover para o próximo campo lógico
                self._move_to_next_field(current)
        else:
            # Se estamos em um botão, executar sua ação
            if hasattr(current, 'invoke'):
                current.invoke()

        return 'break'  # Previne comportamento padrão

    def _handle_field_enter(self, field_type):
        """Retorna função handler específica para cada tipo de campo."""
        def handler():
            if field_type == 'email':
                # Enter no email: ir para senha
                if hasattr(self, 'entry_login_password'):
                    self.entry_login_password.focus_set()
            elif field_type == 'password':
                # Enter na senha: fazer login
                if hasattr(self, 'perform_login'):
                    self.perform_login()
            elif field_type == 'signup_name':
                # Enter no nome: ir para email
                if hasattr(self, 'entry_signup_email'):
                    self.entry_signup_email.focus_set()
            elif field_type == 'signup_email':
                # Enter no email de signup: ir para senha
                if hasattr(self, 'entry_signup_password'):
                    self.entry_signup_password.focus_set()
            elif field_type == 'signup_password':
                # Enter na senha de signup: ir para confirmação
                if hasattr(self, 'entry_signup_confirm'):
                    self.entry_signup_confirm.focus_set()
            elif field_type == 'signup_confirm':
                # Enter na confirmação: fazer signup
                if hasattr(self, 'perform_signup'):
                    self.perform_signup()

        return handler

    def _move_to_next_field(self, current_field):
        """Move o foco para o próximo campo lógico."""
        if current_field == getattr(self, 'entry_login_email', None):
            if hasattr(self, 'entry_login_password'):
                self.entry_login_password.focus_set()
        elif current_field == getattr(self, 'entry_signup_name', None):
            if hasattr(self, 'entry_signup_email'):
                self.entry_signup_email.focus_set()
        elif current_field == getattr(self, 'entry_signup_email', None):
            if hasattr(self, 'entry_signup_password'):
                self.entry_signup_password.focus_set()
        elif current_field == getattr(self, 'entry_signup_password', None):
            if hasattr(self, 'entry_signup_confirm'):
                self.entry_signup_confirm.focus_set()

    def _handle_escape_key(self, event):
        """Gerencia tecla Escape para fechar formulários ou voltar."""
        # Se estamos em um formulário de login/signup, voltar
        if hasattr(self, 'hide_auth_fields'):
            self.hide_auth_fields()
        else:
            # Caso contrário, fechar a janela
            self.on_close()

        return 'break'

    def process_queue(self):
        try:
            while True:
                event_name = self.queue.get_nowait()
                if hasattr(self, "winfo_exists") and not self.winfo_exists():
                    return
                self.event_generate(event_name)
        except queue.Empty:
            pass
        if hasattr(self, "winfo_exists") and self.winfo_exists():
            self.after(100, self.process_queue)

    def set_loading(self, is_loading, message=""):
        if is_loading:
            self._set_status_text(message, self.colors["primary"])
            self.config(cursor="watch")
            if hasattr(self, 'btn_guest'): self.btn_guest.configure(state="disabled")
            if hasattr(self, 'btn_login'): self.btn_login.configure(state="disabled")
            if hasattr(self, 'btn_signup'): self.btn_signup.configure(state="disabled")
            if hasattr(self, 'btn_verify'): self.btn_verify.configure(state="disabled")
        else:
            self.config(cursor="")
            if hasattr(self, 'btn_guest'): self.btn_guest.configure(state="normal")
            if hasattr(self, 'btn_login'): self.btn_login.configure(state="normal")
            if hasattr(self, 'btn_signup'): self.btn_signup.configure(state="normal")
            if hasattr(self, 'btn_verify'): self.btn_verify.configure(state="normal")

    def start_guest_mode(self):
        self.set_loading(True, _("Iniciando modo visitante..."))
        threading.Thread(target=self._guest_login_thread, daemon=True).start()

    def perform_login(self):
        print("[DEBUG] perform_login called")
        email = self.entry_login_email.get().strip()
        password = self.entry_login_password.get().strip()
        errors = []
        if not email: errors.append(_("Email necessário."))
        if not password: errors.append(_("Senha necessária."))
        
        if errors:
            msg = " • ".join(errors)
            self._set_status_text(msg, self.colors["error"])
            messagebox.showerror(_("Erro de Validação"), msg, parent=self)
            return

        print("[DEBUG] Starting login thread")
        self.set_loading(True, _("Autenticando..."))
        threading.Thread(target=self._login_thread, args=(email, password), daemon=True).start()

    def perform_signup(self):
        name = self.entry_signup_name.get().strip()
        email = self.entry_signup_email.get().strip()
        password = self.entry_signup_password.get()
        confirm_password = self.entry_signup_confirm.get()
        
        errors = []
        if not name: errors.append(_("Nome necessário."))
        if name and len(name) > 100: errors.append(_("Nome deve ter no máximo 100 caracteres."))
        if not email: errors.append(_("Email necessário."))
        if not password: errors.append(_("Senha necessária."))
        if len(password) < 8: errors.append(_("Senha deve ter pelo menos 8 caracteres."))
        if password != confirm_password: errors.append(_("Senhas não coincidem."))
        
        # Validação de email mais robusta
        import re
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if email and not re.match(email_regex, email):
            errors.append(_("Email inválido."))
        
        if errors:
            msg = " • ".join(errors)
            self._set_status_text(msg, self.colors["error"])
            messagebox.showerror(_("Erro de Validação"), msg, parent=self)
            return

        self.set_loading(True, _("Criando conta..."))
        threading.Thread(target=self._signup_thread, args=(name, email, password), daemon=True).start()

    def perform_verify(self):
        token = self.entry_verify_token.get().strip()
        
        if not token:
            self._set_status_text(_("O campo do código não pode estar vazio."), self.colors["error"])
            messagebox.showerror(_("Erro de Validação"), _("O campo do código não pode estar vazio."), parent=self)
            return

        self.set_loading(True, _("Verificando conta..."))
        threading.Thread(target=self._verify_thread, args=(token,), daemon=True).start()

    def on_logo_click(self, event):
        self.logo_clicks += 1
        if self.logo_clicks >= 5:
            self.activate_emergency_mode()

    def on_pro_link_click(self, event):
        """Abre a página de checkout PRO no navegador."""
        import webbrowser
        try:
            webbrowser.open("https://voxfluens.com/checkout/pro")
        except Exception as e:
            print(f"Erro ao abrir navegador: {e}")

    def activate_emergency_mode(self):
        confirmed = messagebox.askyesno(
            _("Modo de Emergência"), 
            _("Deseja ativar o modo de emergência (Chaves Locais)?\nIsso deve ser usado apenas se o servidor estiver indisponível."),
            parent=self
        )
        if confirmed:
            self._save_window_position()
            config_manager.set_force_local_mode(True)
            self.destroy()
            self.on_success_callback()

    # --- Threads ---

    def _guest_login_thread(self):
        try:
            try:
                device_id = config_manager.get_or_create_device_id()
            except Exception as e:
                print(f"Device ID Error: {e}")
                device_id = config_manager.get_or_create_device_id()

            cfg = config_manager.load_config()
            ui_language = cfg.get("language", "en-US")
            
            # Detecta país para incluir no request
            from ui.plan_selector_frame import detect_currency
            billing_country = detect_currency()
            
            response = requests.post(
                f"{config_manager.API_BASE_URL}/api/v1/bootstrap/guest",
                json={"ui_language": ui_language, "device_id": device_id, "billing_country": billing_country},
                timeout=10
            )
            self._handle_response(response, is_guest=True)
        except Exception as e:
            self.thread_error_msg = str(e)
            self.queue.put("<<LoginError>>")
        finally:
            self.queue.put("<<StopLoading>>")

    def _login_thread(self, email, password):
        try:
            print("[DEBUG] Calling config_manager.login_user", file=sys.stderr)
            success, payload, err_type = config_manager.login_user(email, password, ui_language="pt-BR")
            print(f"[DEBUG] login_user returned success={success}, err_type={err_type}", file=sys.stderr)
            if success:
                self.thread_result_data = payload
                self.queue.put("<<LoginSuccess>>")
            else:
                self.thread_error_msg = payload
                if err_type == "limit":
                    self.queue.put("<<LimitError>>")
                else:
                    self.queue.put("<<LoginError>>")
        except Exception as e:
            self.thread_error_msg = str(e)
            self.queue.put("<<LoginError>>")
        finally:
            self.queue.put("<<StopLoading>>")

    def _signup_thread(self, name, email, password):
        try:
            response = requests.post(
                f"{config_manager.API_BASE_URL}/api/v1/auth/signup",
                json={"name": name, "email": email, "password": password, "ui_language": i18n.get_current_language()},
                timeout=10
            )
            self._handle_signup_response(response)
        except Exception as e:
            self.thread_error_msg = str(e)
            self.queue.put("<<SignupError>>")
        finally:
            self.queue.put("<<StopLoading>>")

    def _verify_thread(self, token):
        try:
            response = requests.post(
                f"{config_manager.API_BASE_URL}/api/v1/auth/verify",
                json={"token": token, "ui_language": i18n.get_current_language()},
                timeout=10
            )
            self._handle_verify_response(response)
        except Exception as e:
            self.thread_error_msg = _("Erro de conexão. Tente novamente.")
            self.queue.put("<<VerifyError>>")
        finally:
            self.queue.put("<<StopLoading>>")

    def _handle_response(self, response, is_guest):
        if response.status_code == 429:
            self.thread_error_msg = _("Muitas tentativas. Aguarde.")
            self.queue.put("<<LimitError>>")
            return
        if response.status_code == 503:
            self.thread_error_msg = _("Serviço indisponível.")
            self.queue.put("<<LoginError>>")
            return
        if response.status_code == 401 and not is_guest:
            raise Exception(_("Credenciais inválidas."))
        if response.status_code in (403, 500):
            try:
                msg = response.json().get("message", "Erro do servidor")
            except:
                msg = "Erro desconhecido"
            self.thread_error_msg = msg
            self.queue.put("<<LimitError>>")
            return

        response.raise_for_status()
        data = response.json()
        
        if is_guest:
            backend_device_id = data.get("device_id")
            if backend_device_id:
                config_manager.update_device_id(backend_device_id)
            self.thread_result_data = data
            self.queue.put("<<GuestLoginSuccess>>")
        else:
            self.thread_result_data = data
            self.queue.put("<<LoginSuccess>>")
        
    def _handle_signup_response(self, response):
        if response.status_code == 429:
            self.thread_error_msg = _("Muitas tentativas. Aguarde.")
            self.queue.put("<<LimitError>>")
            return
        if response.status_code == 503:
            self.thread_error_msg = _("Serviço indisponível.")
            self.queue.put("<<SignupError>>")
            return
        if response.status_code == 400:
            try:
                data = response.json()
                msg = data.get("message", _("Dados inválidos. Verifique o e-mail e senha."))
            except:
                msg = _("Dados inválidos. Verifique o e-mail e senha.")
            self.thread_error_msg = msg
            self.queue.put("<<SignupError>>")
            return
        if response.status_code == 409:
            try:
                data = response.json()
                msg = data.get("message", _("Email já cadastrado."))
            except:
                msg = _("Email já cadastrado.")
            self.thread_error_msg = msg
            self.queue.put("<<SignupError>>")
            return
        if response.status_code == 422:
            try:
                data = response.json()
                msg = data.get("message", _("Dados inválidos ou incompletos. Verifique os campos."))
            except:
                msg = _("Dados inválidos ou incompletos. Verifique os campos.")
            self.thread_error_msg = msg
            self.queue.put("<<SignupError>>")
            return
        if response.status_code in (403, 500):
            try:
                msg = response.json().get("message", "Erro do servidor")
            except:
                msg = "Erro desconhecido"
            self.thread_error_msg = msg
            self.queue.put("<<SignupError>>")
            return

        response.raise_for_status()
        data = response.json()
        self.thread_result_data = data
        self.queue.put("<<SignupSuccess>>")

    def _handle_verify_response(self, response):
        if response.status_code == 400:
            self.thread_error_msg = _("Código inválido ou expirado. Verifique o e-mail e tente novamente.")
            self.queue.put("<<VerifyError>>")
            return
        if response.status_code == 409:
            self.thread_error_msg = _("Conta já verificada.")
            self.queue.put("<<VerifyError>>")
            return
        if response.status_code in (403, 500):
            try:
                data = response.json()
                msg = data.get("detail", "Erro do servidor")
            except:
                msg = "Erro desconhecido"
            self.thread_error_msg = msg
            self.queue.put("<<VerifyError>>")
            return

        response.raise_for_status()
        data = response.json()
        self.thread_result_data = data
        self.queue.put("<<VerifySuccess>>")

    # --- Event Implementation ---

    def on_guest_login_success_event(self, event):
        if self.thread_result_data:
            self.process_bootstrap_response(self.thread_result_data, is_guest=True)

    def on_login_success_event(self, event):
        print("[DEBUG] on_login_success_event called")
        if self.thread_result_data:
            email = self.entry_login_email.get().strip()
            password = self.entry_login_password.get().strip()
            if email and password:
                config_manager.save_user_credentials(email, password)
            print("[DEBUG] Calling process_bootstrap_response for login")
            self.process_bootstrap_response(self.thread_result_data, is_guest=False)

    def on_signup_success_event(self, event):
        if self.thread_result_data:
            # Verifica se o signup retornou dados de sessão completos
            access_token = self.thread_result_data.get("access_token")
            user = self.thread_result_data.get("user")
            
            if access_token and user:
                # Signup retornou dados completos - faz login automático
                email = self.entry_signup_email.get().strip()
                password = self.entry_signup_password.get()
                if email and password:
                    config_manager.save_user_credentials(email, password)
                self.process_bootstrap_response(self.thread_result_data, is_guest=False)
            else:
                # Signup bem-sucedido, mas sem dados de sessão (possivelmente requer verificação de email)
                self.signup_form_frame.pack_forget()
                self.card_title_label.config(text=_("Conta Criada"))
                self.success_frame.pack(fill="x", expand=True)
                self._restore_window_position()

    def on_verify_success_event(self, event):
        if self.thread_result_data:
            # Verificação bem-sucedida
            self._set_status_text(_("Conta verificada com sucesso! Você pode fazer login agora."), self.colors["success"])
            messagebox.showinfo(_("Sucesso"), _("Conta verificada com sucesso! Você pode fazer login agora."), parent=self)
            # Opcional: voltar para login
            self.show_login_fields()

    def on_verify_error_event(self, event):
        self._set_status_text(self.thread_error_msg or _("Erro na verificação"), self.colors["error"])

    def on_login_error_event(self, event):
        self._set_status_text(self.thread_error_msg or _("Erro desconhecido"), self.colors["error"])

    def on_signup_error_event(self, event):
        self._set_status_text(self.thread_error_msg or _("Erro na criação da conta"), self.colors["error"])

    def on_limit_error_event(self, event):
        self._set_status_text(self.thread_error_msg, self.colors["error"])
        messagebox.showerror(_("Limite Atingido"), self.thread_error_msg, parent=self)

    def on_stop_loading_event(self, event):
        self.set_loading(False)

    def process_bootstrap_response(self, data, is_guest):
        print(f"[DEBUG] process_bootstrap_response called with is_guest={is_guest}")
        access_token = data.get("access_token")
        user = data.get("user", {})
        billing = data.get("billing", {})
        
        print(f"[DEBUG] access_token: {access_token[:10] if access_token else None}...")
        print(f"[DEBUG] server_config in data: transcription={data.get('transcription')}, work={data.get('work')}, image={data.get('image')}")
        
        config_manager.set_session_data(
            access_token=access_token,
            user_id=user.get("id"),
            user_email=user.get("email"),
            user_name=user.get("name"),
            user_plan=user.get("plan"),
            user_language=user.get("language"),
            user_data=user,
            billing=billing,
            server_config={
                "transcription": data.get("transcription"),
                "work": data.get("work"),
                "image": data.get("image")
            },
            limits=data.get("limits", {}),
            is_guest=is_guest
        )
        
        self._save_window_position()
        print("DEBUG: WelcomeWindow processed bootstrap response, calling success callback", file=sys.stderr)

        if self.on_success_callback:
            print("DEBUG: Executing success callback before destroy", file=sys.stderr)
            self._call_success_callback()
        print("DEBUG: Destroying WelcomeWindow", file=sys.stderr)
        self.destroy()

    def _call_success_callback(self):
        print("DEBUG: Executing delayed success callback", file=sys.stderr)
        if self.on_success_callback:
            self.on_success_callback()

    def _show_password_reset(self, event=None):
        from password_reset_window import PasswordResetWindow
        reset_win = PasswordResetWindow(self, on_back_to_login=self.show_login_fields)
        # Não precisa de grab_set extra, pois PasswordResetWindow já cuida disso

    def update_language(self):
        self.title(_("VoxFluens"))
        self.btn_guest.configure(text=_("🚀 Experimentar Agora"))
        if hasattr(self, 'btn_login'):
            self.btn_login.configure(text=_("Entrar"))
        if hasattr(self, 'btn_signup'):
            self.btn_signup.configure(text=_("Criar Conta"))
        self.after(50, self._restore_window_position)

    def on_close(self):
        self._save_window_position()
        self.parent.destroy()
        sys.exit()

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    w = WelcomeWindow(root, lambda: print("Success"))
    root.mainloop()
